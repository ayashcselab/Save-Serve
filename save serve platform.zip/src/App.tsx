import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Toaster } from 'sonner';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Login from './pages/Login';
import Signup from './pages/Signup';
import RestaurantDashboard from './pages/RestaurantDashboard';
import NGODashboard from './pages/NGODashboard';
import PublicDonations from './pages/PublicDonations';
import Donate from './pages/Donate';
import DonationSuccess from './pages/DonationSuccess';
import DonationCancel from './pages/DonationCancel';
import AdminDashboard from './pages/AdminDashboard';
import Profile from './pages/Profile';
import About from './pages/About';
import Contact from './pages/Contact';
import { Loader2 } from 'lucide-react';

const ProtectedRoute = ({ children, allowedRole }: { children: React.ReactNode, allowedRole?: string }) => {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-white">
        <Loader2 className="animate-spin text-green-600" size={48} />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" />;
  }

  if (allowedRole && profile?.role !== allowedRole && profile?.role !== 'Admin') {
    const target = profile?.role === 'Restaurant' ? '/restaurant-dashboard' : '/ngo-dashboard';
    return <Navigate to={target} />;
  }

  return <>{children}</>;
};

const PublicRoute = ({ children }: { children: React.ReactNode }) => {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-white">
        <Loader2 className="animate-spin text-green-600" size={48} />
      </div>
    );
  }

  if (user && profile) {
    if (profile.role === 'Admin') return <Navigate to="/admin" />;
    const target = profile.role === 'Restaurant' ? '/restaurant-dashboard' : '/ngo-dashboard';
    return <Navigate to={target} />;
  }

  return <>{children}</>;
};

function AppContent() {
  const { user, profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-white">
        <Loader2 className="animate-spin text-green-600" size={48} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white font-sans text-gray-900 antialiased">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
        <Route path="/signup" element={<PublicRoute><Signup /></PublicRoute>} />
        <Route path="/public-donations" element={<PublicDonations />} />
        <Route path="/donate" element={<Donate />} />
        <Route path="/donate/success" element={<DonationSuccess />} />
        <Route path="/donate/cancel" element={<DonationCancel />} />
        <Route 
          path="/profile" 
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          } 
        />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        
        <Route 
          path="/restaurant-dashboard" 
          element={
            <ProtectedRoute allowedRole="Restaurant">
              <RestaurantDashboard />
            </ProtectedRoute>
          } 
        />
        
        <Route 
          path="/ngo-dashboard" 
          element={
            <ProtectedRoute allowedRole="NGO">
              <NGODashboard />
            </ProtectedRoute>
          } 
        />

        <Route 
          path="/admin" 
          element={
            <ProtectedRoute allowedRole="Admin">
              <AdminDashboard />
            </ProtectedRoute>
          } 
        />
        
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      <Toaster position="top-center" richColors />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppContent />
      </Router>
    </AuthProvider>
  );
}
