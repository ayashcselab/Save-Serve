export type FoodStatus = 'Available' | 'Accepted' | 'On The Way' | 'Collected' | 'Distributed' | 'Expired';

export interface StatusUpdate {
  status: FoodStatus;
  timestamp: any;
  updatedBy: string;
  notes?: string;
}

export interface FoodItem {
  id: string;
  restaurantId: string;
  restaurantName: string;
  ngoId?: string;
  ngoName?: string;
  name: string;
  category: string;
  quantity: string;
  imageUrl?: string;
  pickupTime: any;
  location: string;
  status: FoodStatus;
  priority: 'Normal' | 'Urgent';
  
  // Location
  lat?: number;
  lng?: number;
  
  // Timestamps
  createdAt: any;
  acceptedAt?: any;
  pickupStartedAt?: any;
  receivedAt?: any;
  distributedAt?: any;
  updatedAt: any;
  
  // History
  statusHistory: StatusUpdate[];
  createdBy: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  name: string;
  role: 'Restaurant' | 'NGO' | 'Admin';
  location: string;
  lat?: number;
  lng?: number;
  phone?: string;
  createdAt: any;
  
  // Stats
  totalDonations?: number;
  totalQuantityDonated?: number;
  totalCollections?: number;
  totalDistributed?: number;
}
