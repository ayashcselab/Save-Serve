import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase/firebase';
import { toast } from 'sonner';
import { handleFirestoreError, OperationType } from '../firebase/errorHandler';
import { Loader2, Mail, Lock, User, MapPin, Phone, Building2, Heart } from 'lucide-react';

const Signup = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [role, setRole] = useState<'Restaurant' | 'NGO'>('Restaurant');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    location: '',
    contact: '',
  });

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      const user = userCredential.user;

      await setDoc(doc(db, 'users', user.uid), {
        uid: user.uid,
        name: formData.name,
        email: formData.email,
        role: role,
        location: formData.location,
        contact: formData.contact,
        createdAt: serverTimestamp(),
      });

      toast.success('Account created successfully!');
      navigate(role === 'Restaurant' ? '/restaurant-dashboard' : '/ngo-dashboard');
    } catch (error: any) {
      console.error("Signup error:", error);
      if (error.code?.startsWith('auth/')) {
        toast.error(error.message || 'Failed to create account');
      } else {
        handleFirestoreError(error, OperationType.CREATE, `users/${formData.email}`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center bg-gray-50 px-4 py-12">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-green-600 p-8 text-center text-white">
          <h2 className="text-3xl font-bold mb-2">Join Save & Serve</h2>
          <p className="text-green-100">Start making a difference today</p>
        </div>

        <form onSubmit={handleSignup} className="p-8 space-y-5">
          {/* Role Selection */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <button
              type="button"
              onClick={() => setRole('Restaurant')}
              className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${
                role === 'Restaurant' ? 'border-green-600 bg-green-50 text-green-600' : 'border-gray-100 text-gray-400 hover:border-gray-200'
              }`}
            >
              <Building2 size={24} className="mb-2" />
              <span className="text-sm font-bold">Restaurant</span>
            </button>
            <button
              type="button"
              onClick={() => setRole('NGO')}
              className={`flex flex-col items-center justify-center p-4 rounded-xl border-2 transition-all ${
                role === 'NGO' ? 'border-green-600 bg-green-50 text-green-600' : 'border-gray-100 text-gray-400 hover:border-gray-200'
              }`}
            >
              <Heart size={24} className="mb-2" />
              <span className="text-sm font-bold">NGO</span>
            </button>
          </div>

          <div className="space-y-4">
            <div className="relative">
              <User className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                required
                type="text"
                placeholder={role === 'Restaurant' ? "Restaurant Name" : "NGO Name"}
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            <div className="relative">
              <Mail className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                required
                type="email"
                placeholder="Email Address"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                required
                type="password"
                placeholder="Password"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              />
            </div>

            <div className="relative">
              <Phone className="absolute left-3 top-3 text-gray-400" size={20} />
              <input
                required
                type="tel"
                placeholder="Contact Number"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                value={formData.contact}
                onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
              />
            </div>

            <div className="relative">
              <MapPin className="absolute left-3 top-3 text-gray-400" size={20} />
              <textarea
                required
                placeholder="Full Address / Location"
                className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none resize-none h-24"
                value={formData.location}
                onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-green-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-700 transition-all shadow-lg shadow-green-100 flex items-center justify-center space-x-2 disabled:opacity-70"
          >
            {loading ? <Loader2 className="animate-spin" /> : <span>Create Account</span>}
          </button>

          <p className="text-center text-gray-500 mt-6">
            Already have an account?{' '}
            <Link to="/login" className="text-green-600 font-bold hover:underline">
              Login
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Signup;
