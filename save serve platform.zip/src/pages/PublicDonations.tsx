import React, { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  limit 
} from 'firebase/firestore';
import { db } from '../firebase/firebase';
import FoodCard from '../components/FoodCard';
import { Search, MapPin, Filter, Utensils, List, Map as MapIcon } from 'lucide-react';
import { handleFirestoreError, OperationType } from '../firebase/errorHandler';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { motion, AnimatePresence } from 'motion/react';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

const PublicDonations = () => {
  const [foodItems, setFoodItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  useEffect(() => {
    // Only show available food items publicly
    const q = query(
      collection(db, 'foodItems'),
      where('status', '==', 'Available'),
      where('isDeleted', '==', false),
      limit(50)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map(doc => {
        const data = doc.data();
        // If no lat/lng, provide some default ones based on index for demo purposes
        // In a real app, these would be saved in the document
        return { 
          id: doc.id, 
          ...data,
          lat: data.lat || (23.8103 + (Math.random() - 0.5) * 0.1), // Default to Dhaka area
          lng: data.lng || (90.4125 + (Math.random() - 0.5) * 0.1)
        };
      });
      
      // Client-side sorting
      items.sort((a: any, b: any) => {
        const timeA = a.createdAt?.toMillis?.() || 0;
        const timeB = b.createdAt?.toMillis?.() || 0;
        return timeB - timeA;
      });

      setFoodItems(items);
      setLoading(false);
    }, (error: any) => {
      console.error("Error fetching public donations:", error);
      handleFirestoreError(error, OperationType.LIST, 'foodItems');
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const filteredItems = foodItems.filter(item => 
    item.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.restaurantName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#f8fafc] pb-20">
      {/* Hero Section */}
      <div className="bg-gray-900 py-20 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-green-600/10" />
        <div className="max-w-7xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl md:text-7xl font-black text-white mb-6 tracking-tighter">
              LIVE <span className="text-green-500">RESCUE</span> MAP
            </h1>
            <p className="text-gray-400 text-xl max-w-2xl mx-auto font-medium">
              Real-time visualization of surplus food available for rescue. 
              Connecting abundance with need, one meal at a time.
            </p>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-20">
        {/* Search and Toggle Bar */}
        <div className="bg-white rounded-[32px] shadow-2xl shadow-gray-200/50 p-4 md:p-6 flex flex-col md:flex-row gap-4 items-center border border-gray-100">
          <div className="relative flex-1 w-full">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by food, restaurant, or location..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-16 pr-6 py-5 bg-gray-50 border-none rounded-2xl font-bold text-gray-900 focus:ring-2 focus:ring-green-500 transition-all"
            />
          </div>
          <div className="flex bg-gray-100 p-1.5 rounded-2xl w-full md:w-auto">
            <button 
              onClick={() => setViewMode('list')}
              className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${
                viewMode === 'list' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <List size={16} />
              List
            </button>
            <button 
              onClick={() => setViewMode('map')}
              className={`flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all ${
                viewMode === 'map' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <MapIcon size={16} />
              Map
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="mt-12">
          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3, 4, 5, 6].map(i => (
                <div key={i} className="bg-white h-96 rounded-[40px] animate-pulse border border-gray-100" />
              ))}
            </div>
          ) : (
            <AnimatePresence mode="wait">
              {viewMode === 'list' ? (
                <motion.div 
                  key="list"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                >
                  {filteredItems.length > 0 ? (
                    filteredItems.map(item => (
                      <div key={item.id} className="relative group">
                        <FoodCard item={item} />
                        <div className="absolute inset-0 bg-white/10 backdrop-blur-[1px] opacity-0 group-hover:opacity-100 transition-all rounded-[40px] flex items-center justify-center pointer-events-none">
                          <div className="bg-gray-900 text-white px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest shadow-2xl transform translate-y-4 group-hover:translate-y-0 transition-all">
                            Login to Claim
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-full text-center py-32 bg-white rounded-[48px] border-2 border-dashed border-gray-100">
                      <Utensils className="w-20 h-20 text-gray-200 mx-auto mb-6" />
                      <h3 className="text-2xl font-black text-gray-900">No active donations found</h3>
                      <p className="text-gray-500 font-medium mt-2">Try adjusting your search or check back later.</p>
                    </div>
                  )}
                </motion.div>
              ) : (
                <motion.div 
                  key="map"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="h-[600px] rounded-[48px] overflow-hidden shadow-2xl border-8 border-white relative"
                >
                  <MapContainer 
                    center={[23.8103, 90.4125]} 
                    zoom={12} 
                    style={{ height: '100%', width: '100%' }}
                    scrollWheelZoom={false}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    {filteredItems.map(item => (
                      <Marker key={item.id} position={[item.lat, item.lng]}>
                        <Popup className="custom-popup">
                          <div className="p-2 min-w-[200px]">
                            <div className="flex items-center space-x-2 mb-2">
                              <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center text-green-600">
                                <Utensils size={16} />
                              </div>
                              <h4 className="font-black text-gray-900">{item.name}</h4>
                            </div>
                            <p className="text-xs font-bold text-gray-500 mb-3 flex items-center space-x-1">
                              <MapPin size={12} />
                              <span>{item.location}</span>
                            </p>
                            <div className="flex justify-between items-center pt-2 border-t border-gray-100">
                              <span className="text-[10px] font-black text-green-600 uppercase tracking-widest">{item.quantity}</span>
                              <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{item.restaurantName}</span>
                            </div>
                          </div>
                        </Popup>
                      </Marker>
                    ))}
                  </MapContainer>
                  
                  {/* Map Overlay Info */}
                  <div className="absolute bottom-8 left-8 z-[1000] bg-white/90 backdrop-blur-md p-4 rounded-2xl shadow-xl border border-white/20">
                    <div className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                      <span className="text-xs font-black uppercase tracking-widest text-gray-900">
                        {filteredItems.length} Live Donations
                      </span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          )}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        .leaflet-container {
          z-index: 1;
        }
        .custom-popup .leaflet-popup-content-wrapper {
          border-radius: 24px;
          padding: 8px;
          box-shadow: 0 20px 25px -5px rgb(0 0 0 / 0.1);
        }
        .custom-popup .leaflet-popup-tip {
          box-shadow: none;
        }
      `}} />
    </div>
  );
};

export default PublicDonations;
