import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy, limit } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { useAuth } from '../context/AuthContext';
import { Card, Badge, Button } from '../components/UI';
import { 
  Utensils, 
  HandHeart, 
  TrendingUp, 
  Clock, 
  MapPin, 
  ChevronRight,
  AlertCircle
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

export const Dashboard: React.FC = () => {
  const { user, profile, isRestaurant, isNGO } = useAuth();
  const [stats, setStats] = useState({
    totalDonated: 0,
    totalCollected: 0,
    activeDonations: 0,
    restaurantsCount: 0,
    availableFoodCount: 0,
  });
  const [recentFood, setRecentFood] = useState<any[]>([]);
  const [analyticsData, setAnalyticsData] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;

    // Real-time food items
    const foodQuery = isRestaurant 
      ? query(collection(db, 'foodItems'), where('restaurantId', '==', user.uid))
      : query(collection(db, 'foodItems'), where('status', '==', 'Available'));

    const unsubscribeFood = onSnapshot(foodQuery, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      // Client-side sort to avoid composite index requirement
      items.sort((a: any, b: any) => {
        const timeA = a.createdAt?.toMillis() || 0;
        const timeB = b.createdAt?.toMillis() || 0;
        return timeB - timeA;
      });
      setRecentFood(items.slice(0, 5));
    }, (error) => {
      console.error("Firestore Error in Dashboard foodQuery:", error);
    });

    // Stats calculation
    const statsUnsubscribe = onSnapshot(collection(db, 'foodItems'), (snapshot) => {
      const docs = snapshot.docs.map(d => d.data());
      if (isRestaurant) {
        setStats(prev => ({
          ...prev,
          totalDonated: docs.filter(d => d.restaurantId === user.uid).length,
          activeDonations: docs.filter(d => d.restaurantId === user.uid && d.status === 'Available').length
        }));
      } else {
        setStats(prev => ({
          ...prev,
          availableFoodCount: docs.filter(d => d.status === 'Available').length,
          totalCollected: docs.filter(d => d.ngoId === user.uid && d.status === 'Collected').length
        }));
      }
    }, (error) => {
      console.error("Firestore Error in Dashboard statsUnsubscribe:", error);
    });

    // Analytics data
    const analyticsQuery = query(collection(db, 'analytics'), limit(30));
    const unsubscribeAnalytics = onSnapshot(analyticsQuery, (snapshot) => {
      const analytics = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timestamp: doc.data().timestamp?.toDate() || new Date()
      }));
      
      // Sort by timestamp
      analytics.sort((a: any, b: any) => a.timestamp - b.timestamp);

      setAnalyticsData(analytics.slice(-7).map((item: any) => ({
        name: item.timestamp.toLocaleDateString('en-US', { weekday: 'short' }),
        donated: item.totalDonated || 0,
        collected: item.totalCollected || 0,
      })));
    }, (error) => {
      console.error("Firestore Error in Dashboard analyticsQuery:", error);
    });

    return () => {
      unsubscribeFood();
      statsUnsubscribe();
      unsubscribeAnalytics();
    };
  }, [user, isRestaurant, isNGO]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Welcome back, {profile?.name}</h1>
        <p className="text-slate-500">Here's what's happening with your food rescue efforts today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {isRestaurant ? (
          <>
            <StatCard title="Total Donated" value={stats.totalDonated} icon={Utensils} color="bg-emerald-500" />
            <StatCard title="Active Donations" value={stats.activeDonations} icon={Clock} color="bg-amber-500" />
            <StatCard title="Impact Score" value={stats.totalDonated * 10} icon={TrendingUp} color="bg-blue-500" />
            <StatCard title="People Fed" value={stats.totalDonated * 4} icon={HandHeart} color="bg-rose-500" />
          </>
        ) : (
          <>
            <StatCard title="Available Food" value={stats.availableFoodCount} icon={Utensils} color="bg-emerald-500" />
            <StatCard title="Total Collected" value={stats.totalCollected} icon={HandHeart} color="bg-blue-500" />
            <StatCard title="Active Pickups" value={recentFood.filter(f => f.status === 'Accepted').length} icon={Clock} color="bg-amber-500" />
            <StatCard title="Distribution Points" value={3} icon={MapPin} color="bg-rose-500" />
          </>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Analytics Chart */}
        <Card className="lg:col-span-2 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-900">Activity Overview</h3>
            <select className="bg-slate-50 border-none text-sm font-medium rounded-lg px-3 py-1">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={analyticsData}>
                <defs>
                  <linearGradient id="colorDonated" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                />
                <Area type="monotone" dataKey="donated" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#colorDonated)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-slate-900">Recent Activity</h3>
            <Button variant="ghost" className="text-xs">View All</Button>
          </div>
          <div className="space-y-4">
            {recentFood.length > 0 ? recentFood.map((item) => (
              <div key={item.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-slate-50 transition-colors border border-transparent hover:border-slate-100">
                <div className="w-12 h-12 rounded-xl bg-slate-100 flex-shrink-0 overflow-hidden">
                  {item.imageURL ? (
                    <img src={item.imageURL} alt={item.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-400">
                      <Utensils size={20} />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-slate-900 truncate">{item.name}</p>
                  <p className="text-xs text-slate-500">{item.quantity} • {item.location}</p>
                </div>
                <Badge variant={item.status === 'Available' ? 'success' : 'warning'}>
                  {item.status}
                </Badge>
              </div>
            )) : (
              <div className="text-center py-12">
                <AlertCircle className="mx-auto text-slate-300 mb-2" size={32} />
                <p className="text-slate-500 text-sm">No recent activity found.</p>
              </div>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string; value: number | string; icon: any; color: string }> = ({ title, value, icon: Icon, color }) => (
  <Card className="p-6">
    <div className="flex items-center justify-between mb-4">
      <div className={`w-12 h-12 rounded-2xl ${color} flex items-center justify-center text-white shadow-lg shadow-opacity-20`}>
        <Icon size={24} />
      </div>
      <Badge variant="neutral">+12%</Badge>
    </div>
    <h4 className="text-slate-500 text-sm font-medium">{title}</h4>
    <p className="text-3xl font-black text-slate-900 mt-1">{value}</p>
  </Card>
);
