import React, { useEffect, useState, useMemo } from 'react';
import { collection, query, where, onSnapshot, orderBy, updateDoc, doc, addDoc, serverTimestamp, getDocs } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { useAuth } from '../context/AuthContext';
import FoodCard from '../components/FoodCard';
import { Link } from 'react-router-dom';
import { Heart, CheckCircle2, History, Search, LayoutDashboard, Users, Utensils, PackageCheck, TrendingUp, Timer, MapPin, Package, Calendar, Map as MapIcon, List, Building2, User } from 'lucide-react';
import { toast } from 'sonner';
import { sendNotification } from '../services/NotificationService';
import { handleFirestoreError, OperationType } from '../firebase/errorHandler';
import { startOfDay, startOfWeek, startOfMonth, startOfYear, isAfter, differenceInMinutes, format } from 'date-fns';
import { FoodItem, FoodStatus } from '../types';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

const NGODashboard = () => {
  const { profile } = useAuth();
  const [availableFood, setAvailableFood] = useState<FoodItem[]>([]);
  const [myPickups, setMyPickups] = useState<FoodItem[]>([]);
  const [allRestaurants, setAllRestaurants] = useState<number>(0);
  const [totalFoodAvailable, setTotalFoodAvailable] = useState<number>(0);
  const [totalFoodCollected, setTotalFoodCollected] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'available' | 'pickups' | 'analytics'>('available');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  useEffect(() => {
    if (!profile) return;

    // Listen for available food
    const qAvailable = query(
      collection(db, 'foodItems'),
      where('status', '==', 'Available'),
      where('isDeleted', '==', false)
    );

    const unsubscribeAvailable = onSnapshot(qAvailable, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as FoodItem[];
      
      // Client-side sorting to avoid index requirement
      items.sort((a, b) => {
        const timeA = a.createdAt?.toMillis?.() || 0;
        const timeB = b.createdAt?.toMillis?.() || 0;
        return timeB - timeA;
      });

      setAvailableFood(items);
      setTotalFoodAvailable(items.length);
      setLoading(false);
    }, (error: any) => {
      console.error("Error fetching available food:", error);
      if (error.code === 'failed-precondition') {
        console.warn("Missing index for available food query. Please create it using the link in the console.");
        if (unsubscribeAvailable) unsubscribeAvailable();
      } else {
        handleFirestoreError(error, OperationType.LIST, 'foodItems');
      }
      setLoading(false);
    });

    // Listen for all restaurants count
    const qRestaurants = query(collection(db, 'users'), where('role', '==', 'Restaurant'));
    const unsubscribeRestaurants = onSnapshot(qRestaurants, (snapshot) => {
      setAllRestaurants(snapshot.size);
    });

    // Listen for total food collected (global for NGO dashboard stats)
    const qTotalCollected = query(collection(db, 'foodItems'), where('status', 'in', ['Collected', 'Distributed']));
    const unsubscribeTotalCollected = onSnapshot(qTotalCollected, (snapshot) => {
      setTotalFoodCollected(snapshot.size);
    });

    // Listen for NGO's own pickups (or all if Admin)
    let qMyPickups;
    if (profile.role === 'Admin') {
      qMyPickups = query(
        collection(db, 'foodItems'),
        where('status', 'in', ['Accepted', 'On The Way', 'Collected', 'Distributed']),
        where('isDeleted', '==', false)
      );
    } else {
      qMyPickups = query(
        collection(db, 'foodItems'),
        where('ngoId', '==', profile.uid),
        where('isDeleted', '==', false)
      );
    }

    const unsubscribeMyPickups = onSnapshot(qMyPickups as any, (snapshot: any) => {
      const items = snapshot.docs.map((doc: any) => ({ id: doc.id, ...doc.data() })) as FoodItem[];
      
      // Client-side sorting to avoid index requirement
      items.sort((a, b) => {
        const timeA = a.updatedAt?.toMillis?.() || 0;
        const timeB = b.updatedAt?.toMillis?.() || 0;
        return timeB - timeA;
      });

      setMyPickups(items);
    }, (error: any) => {
      console.error("Error fetching my pickups:", error);
      if (error.code === 'failed-precondition') {
        console.warn("Missing index for my pickups query. Please create it using the link in the console.");
        if (unsubscribeMyPickups) unsubscribeMyPickups();
      } else {
        handleFirestoreError(error, OperationType.LIST, 'foodItems');
      }
    });

    // Auto-expiry check
    const checkExpiry = () => {
      const now = new Date();
      availableFood.forEach(async (item) => {
        const pickupTime = item.pickupTime?.toDate ? item.pickupTime.toDate() : new Date(item.pickupTime);
        if (isAfter(now, pickupTime)) {
          try {
            await updateDoc(doc(db, 'foodItems', item.id), {
              status: 'Expired',
              updatedAt: serverTimestamp(),
              statusHistory: [
                ...(item.statusHistory || []),
                {
                  status: 'Expired',
                  timestamp: new Date(),
                  updatedBy: 'system',
                  notes: 'Food donation expired'
                }
              ]
            });
          } catch (e) {
            console.error("Error expiring item:", e);
          }
        }
      });
    };

    const expiryInterval = setInterval(checkExpiry, 60000);

    return () => {
      unsubscribeAvailable();
      unsubscribeRestaurants();
      unsubscribeTotalCollected();
      unsubscribeMyPickups();
      clearInterval(expiryInterval);
    };
  }, [profile, availableFood]);

  const handleUpdateStatus = async (foodId: string, newStatus: FoodStatus) => {
    if (!profile) return;
    const item = myPickups.find(i => i.id === foodId) || availableFood.find(i => i.id === foodId);
    if (!item) return;

    setActionLoading(foodId);
    try {
      const updateData: any = {
        status: newStatus,
        updatedAt: serverTimestamp(),
        statusHistory: [
          ...(item.statusHistory || []),
          {
            status: newStatus,
            timestamp: new Date(),
            updatedBy: profile.uid,
            notes: `Status updated to ${newStatus}`
          }
        ]
      };

      if (newStatus === 'Accepted') {
        updateData.ngoId = profile.uid;
        updateData.ngoName = profile.name;
        updateData.acceptedAt = serverTimestamp();
      } else if (newStatus === 'On The Way') {
        updateData.pickupStartedAt = serverTimestamp();
      } else if (newStatus === 'Collected') {
        updateData.receivedAt = serverTimestamp();
      } else if (newStatus === 'Distributed') {
        updateData.distributedAt = serverTimestamp();
      }

      await updateDoc(doc(db, 'foodItems', foodId), updateData);

      // Notify Restaurant
      let message = '';
      switch (newStatus) {
        case 'Accepted': message = `${profile.name} accepted your donation: ${item.name}`; break;
        case 'On The Way': message = `${profile.name} is on the way to pick up: ${item.name}`; break;
        case 'Collected': message = `${profile.name} has received the food: ${item.name}`; break;
        case 'Distributed': message = `${profile.name} has distributed the food: ${item.name}`; break;
      }

      if (message) {
        await sendNotification(item.restaurantId, message, 'success');
      }

      toast.success(`Food marked as ${newStatus.toLowerCase()}!`);
      if (newStatus === 'Accepted') setActiveTab('pickups');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `foodItems/${foodId}`);
    } finally {
      setActionLoading(null);
    }
  };

  const analytics = useMemo(() => {
    const now = new Date();
    const dayStart = startOfDay(now);
    const weekStart = startOfWeek(now);
    const monthStart = startOfMonth(now);
    const yearStart = startOfYear(now);

    const collectedItems = myPickups.filter(i => i.status === 'Collected' || i.status === 'Distributed');

    const getCount = (start: Date) => {
      return collectedItems.filter(i => {
        const date = i.updatedAt?.toDate ? i.updatedAt.toDate() : new Date();
        return isAfter(date, start);
      }).length;
    };

    // Efficiency Rate: Avg time from Accepted to Collected
    const times = collectedItems
      .filter(i => i.acceptedAt && i.receivedAt)
      .map(i => {
        const start = i.acceptedAt.toDate ? i.acceptedAt.toDate() : new Date(i.acceptedAt);
        const end = i.receivedAt.toDate ? i.receivedAt.toDate() : new Date(i.receivedAt);
        return differenceInMinutes(end, start);
      });
    
    const avgEfficiency = times.length > 0 
      ? Math.round(times.reduce((a, b) => a + b, 0) / times.length) 
      : 0;

    return {
      daily: getCount(dayStart),
      weekly: getCount(weekStart),
      monthly: getCount(monthStart),
      yearly: getCount(yearStart),
      total: collectedItems.length,
      distributed: myPickups.filter(i => i.status === 'Distributed').length,
      avgEfficiency
    };
  }, [myPickups]);

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 py-8 mb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-green-100 rounded-3xl flex items-center justify-center text-green-600 overflow-hidden border-4 border-white shadow-xl">
                {profile?.photoURL ? (
                  <img 
                    src={profile.photoURL} 
                    alt={profile.name} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <Building2 size={32} />
                )}
              </div>
              <div>
                <h1 className="text-2xl md:text-3xl font-black text-gray-900 uppercase tracking-tight">
                  {profile?.name || 'NGO'} Dashboard
                </h1>
                <div className="flex flex-wrap items-center gap-4 mt-2">
                  <p className="text-gray-500 font-bold text-sm flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                    Impact: <span className="font-black text-gray-900">{analytics.total}</span> Items Rescued
                  </p>
                  {profile?.location && (
                    <p className="text-gray-400 font-bold text-sm flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      {profile.location}
                    </p>
                  )}
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <Link 
                to="/profile"
                className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 border border-gray-200 text-sm font-black rounded-2xl text-gray-600 bg-white hover:bg-gray-50 transition-all active:scale-95 gap-2 uppercase tracking-widest"
              >
                <User size={18} />
                Profile
              </Link>
              <div className="flex bg-gray-100 p-1.5 rounded-2xl shadow-inner w-full sm:w-auto">
                {[
                  { id: 'available', label: 'Available', icon: <Search size={16} /> },
                  { id: 'pickups', label: 'Live Pickups', icon: <Timer size={16} /> },
                  { id: 'analytics', label: 'Performance', icon: <TrendingUp size={16} /> },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id as any)}
                    className={`flex-1 sm:flex-none px-6 py-2.5 rounded-xl font-black text-[11px] uppercase tracking-widest transition-all flex items-center justify-center space-x-2 ${
                      activeTab === tab.id ? 'bg-white text-green-600 shadow-md' : 'text-gray-400 hover:text-gray-600'
                    }`}
                  >
                    {tab.icon}
                    <span className="hidden sm:inline">{tab.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Live Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          {[
            { label: 'Partner Restaurants', value: allRestaurants, icon: <Users className="text-blue-500" />, color: 'bg-blue-50' },
            { label: 'Food Available', value: totalFoodAvailable, icon: <Utensils className="text-green-500" />, color: 'bg-green-50' },
            { label: 'Global Rescued', value: totalFoodCollected, icon: <PackageCheck className="text-purple-500" />, color: 'bg-purple-50' },
            { label: 'Efficiency Rate', value: `${analytics.avgEfficiency}m`, icon: <Timer className="text-orange-500" />, color: 'bg-orange-50' },
          ].map((stat, idx) => (
            <div key={idx} className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm flex items-center space-x-4 hover:shadow-md transition-shadow">
              <div className={`p-3.5 ${stat.color} rounded-2xl`}>{stat.icon}</div>
              <div>
                <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest leading-none mb-1">{stat.label}</p>
                <span className="text-2xl font-black text-gray-900">{stat.value}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Content */}
        <div>
          {activeTab === 'analytics' ? (
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight">Performance Metrics</h2>
                <div className="flex items-center space-x-2 text-xs font-bold text-gray-400">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span>Real-time Updates</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: 'Today', value: analytics.daily, sub: 'Items collected today', icon: <Calendar size={20} /> },
                  { label: 'This Week', value: analytics.weekly, sub: 'Items collected this week', icon: <TrendingUp size={20} /> },
                  { label: 'This Month', value: analytics.monthly, sub: 'Items collected this month', icon: <TrendingUp size={20} /> },
                  { label: 'Efficiency', value: `${analytics.avgEfficiency}m`, sub: 'Avg. pickup time', icon: <Timer size={20} /> },
                ].map((item, idx) => (
                  <div key={idx} className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm text-center group hover:border-green-100 transition-colors">
                    <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center mx-auto mb-4 text-gray-400 group-hover:text-green-500 group-hover:bg-green-50 transition-all">
                      {item.icon}
                    </div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">{item.label}</p>
                    <div className="text-4xl font-black text-gray-900 mb-2">{item.value}</div>
                    <p className="text-xs text-gray-400 font-medium">{item.sub}</p>
                  </div>
                ))}
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                  <div className="flex items-center justify-between mb-8">
                    <h3 className="font-black text-gray-900 uppercase tracking-tight">Distribution Impact</h3>
                    <div className="p-2 bg-green-50 rounded-lg">
                      <TrendingUp className="text-green-600" size={20} />
                    </div>
                  </div>
                  <div className="space-y-8">
                    <div>
                      <div className="flex justify-between mb-3">
                        <span className="text-xs font-black text-gray-400 uppercase tracking-widest">Efficiency Progress</span>
                        <span className="text-sm font-black text-green-600">{Math.round((analytics.distributed / (analytics.total || 1)) * 100)}%</span>
                      </div>
                      <div className="w-full bg-gray-50 h-4 rounded-full overflow-hidden border border-gray-100">
                        <div 
                          className="bg-green-500 h-full transition-all duration-1000 ease-out" 
                          style={{ width: `${(analytics.distributed / (analytics.total || 1)) * 100}%` }} 
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Total Collected</p>
                        <p className="text-2xl font-black text-gray-900">{analytics.total}</p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-2xl border border-green-100">
                        <p className="text-[10px] font-black text-green-600 uppercase tracking-widest mb-1">Total Distributed</p>
                        <p className="text-2xl font-black text-green-700">{analytics.distributed}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-900 p-8 rounded-3xl shadow-xl text-white overflow-hidden relative">
                  <div className="relative z-10">
                    <h3 className="font-black uppercase tracking-tight mb-6">Recent Activity Log</h3>
                    <div className="space-y-6">
                      {myPickups.slice(0, 3).map((item, idx) => (
                        <div key={idx} className="flex items-start space-x-4">
                          <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
                            <Package size={20} className="text-green-400" />
                          </div>
                          <div>
                            <p className="text-sm font-bold">{item.name}</p>
                            <p className="text-[10px] text-gray-400 font-medium">{item.status} • {format(item.updatedAt?.toDate ? item.updatedAt.toDate() : new Date(), 'MMM d, h:mm a')}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <button 
                      onClick={() => setActiveTab('pickups')}
                      className="mt-8 w-full py-3 bg-white/10 hover:bg-white/20 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
                    >
                      View All History
                    </button>
                  </div>
                  <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-green-500/10 rounded-full blur-3xl" />
                </div>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-xl font-black text-gray-900 uppercase tracking-tight">
                  {activeTab === 'available' ? 'Available Rescue Missions' : 'Active Logistics Tracking'}
                </h2>
                {activeTab === 'available' && (
                  <div className="flex items-center space-x-4">
                    <div className="flex bg-gray-100 p-1 rounded-xl shadow-sm border border-gray-100">
                      <button 
                        onClick={() => setViewMode('list')}
                        className={`p-2 rounded-lg transition-all ${viewMode === 'list' ? 'bg-green-600 text-white shadow-md' : 'text-gray-400 hover:bg-gray-50'}`}
                      >
                        <List size={16} />
                      </button>
                      <button 
                        onClick={() => setViewMode('map')}
                        className={`p-2 rounded-lg transition-all ${viewMode === 'map' ? 'bg-green-600 text-white shadow-md' : 'text-gray-400 hover:bg-gray-50'}`}
                      >
                        <MapIcon size={16} />
                      </button>
                    </div>
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{availableFood.length} Missions Found</span>
                  </div>
                )}
              </div>

              {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="bg-white h-80 rounded-3xl animate-pulse border border-gray-100 shadow-sm" />
                  ))}
                </div>
              ) : (
                <>
                  {activeTab === 'available' ? (
                    viewMode === 'list' ? (
                      availableFood.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                          {availableFood.map(item => (
                            <FoodCard 
                              key={item.id} 
                              item={item} 
                              onAction={handleUpdateStatus}
                              isActionLoading={actionLoading === item.id}
                              userRole="NGO"
                            />
                          ))}
                        </div>
                      ) : (
                        <div className="bg-white rounded-[2rem] border border-gray-100 p-16 text-center shadow-sm">
                          <div className="w-24 h-24 bg-gray-50 rounded-[2rem] flex items-center justify-center mx-auto mb-6">
                            <Search className="text-gray-200" size={48} />
                          </div>
                          <h3 className="text-2xl font-black text-gray-900 mb-2 uppercase tracking-tight">No Missions Available</h3>
                          <p className="text-gray-500 font-medium max-w-xs mx-auto">All surplus food has been rescued! Check back soon for new opportunities.</p>
                        </div>
                      )
                    ) : (
                      <div className="h-[600px] rounded-[40px] overflow-hidden border-4 border-white shadow-xl relative z-10">
                        <MapContainer 
                          center={[23.8103, 90.4125]} 
                          zoom={12} 
                          style={{ height: '100%', width: '100%' }}
                        >
                          <TileLayer
                            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                          />
                          {availableFood.map((item) => (
                            <Marker 
                              key={item.id} 
                              position={[item.lat || 23.8103, item.lng || 90.4125]}
                            >
                              <Popup className="custom-popup">
                                <div className="p-2 min-w-[200px]">
                                  <img 
                                    src={item.imageUrl} 
                                    alt={item.name} 
                                    className="w-full h-24 object-cover rounded-xl mb-2"
                                    referrerPolicy="no-referrer"
                                  />
                                  <h4 className="font-black text-gray-900 leading-tight">{item.name}</h4>
                                  <p className="text-xs text-gray-500 font-bold mt-1">{item.restaurantName}</p>
                                  <div className="flex items-center justify-between mt-3 pt-2 border-t border-gray-100">
                                    <span className="text-xs font-black text-green-600">{item.quantity}</span>
                                    <button 
                                      onClick={() => handleUpdateStatus(item.id!, 'Accepted')}
                                      className="text-[10px] font-black uppercase tracking-widest bg-green-600 text-white px-3 py-1.5 rounded-lg hover:bg-green-700 transition-all"
                                    >
                                      Accept
                                    </button>
                                  </div>
                                </div>
                              </Popup>
                            </Marker>
                          ))}
                        </MapContainer>
                        <style dangerouslySetInnerHTML={{ __html: `
                          .custom-popup .leaflet-popup-content-wrapper {
                            border-radius: 24px;
                            padding: 0;
                            overflow: hidden;
                          }
                          .custom-popup .leaflet-popup-content {
                            margin: 0;
                          }
                        `}} />
                      </div>
                    )
                  ) : (
                    myPickups.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {myPickups.map(item => (
                          <FoodCard 
                            key={item.id} 
                            item={item} 
                            onAction={item.status !== 'Distributed' ? handleUpdateStatus : undefined}
                            isActionLoading={actionLoading === item.id}
                            userRole="NGO"
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="bg-white rounded-[2rem] border border-gray-100 p-16 text-center shadow-sm">
                        <div className="w-24 h-24 bg-gray-50 rounded-[2rem] flex items-center justify-center mx-auto mb-6">
                          <Timer className="text-gray-200" size={48} />
                        </div>
                        <h3 className="text-2xl font-black text-gray-900 mb-2 uppercase tracking-tight">No Active Pickups</h3>
                        <p className="text-gray-500 font-medium max-w-xs mx-auto">Accept a mission from the "Available" tab to start tracking your impact.</p>
                      </div>
                    )
                  )}
                </>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default NGODashboard;
