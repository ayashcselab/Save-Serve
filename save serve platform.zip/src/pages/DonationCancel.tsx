import React from 'react';
import { motion } from 'motion/react';
import { XCircle, ArrowLeft, Heart, MessageCircle, HelpCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const DonationCancel = () => {
  return (
    <div className="min-h-screen bg-[#fcf8f8] flex items-center justify-center p-6 pt-24">
      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 md:p-12 rounded-[48px] shadow-[0_32px_64px_-16px_rgba(220,38,38,0.1)] border border-red-50 max-w-2xl w-full text-center relative overflow-hidden"
      >
        {/* Decorative background elements */}
        <div className="absolute top-0 left-0 w-full h-2 bg-red-500" />
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-red-50 rounded-full blur-3xl opacity-50" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-red-50 rounded-full blur-3xl opacity-50" />

        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 12, stiffness: 200, delay: 0.2 }}
          className="w-24 h-24 bg-red-100 text-red-600 rounded-[32px] flex items-center justify-center mx-auto mb-8 shadow-inner"
        >
          <XCircle size={48} strokeWidth={2.5} />
        </motion.div>

        <h1 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tight mb-4">
          Payment Cancelled
        </h1>
        
        <p className="text-lg text-gray-600 font-bold mb-10 max-w-md mx-auto leading-relaxed">
          Your donation process was cancelled. No charges were made. If you encountered a technical issue, we'd love to help you resolve it.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10">
          <Link 
            to="/donate" 
            className="flex-1 py-5 bg-gray-900 text-white rounded-2xl font-black flex items-center justify-center space-x-3 hover:bg-black transition-all group shadow-lg shadow-gray-200"
          >
            <ArrowLeft size={20} className="group-hover:-translate-x-2 transition-transform" />
            <span>Try Again</span>
          </Link>
          <Link 
            to="/contact" 
            className="flex-1 py-5 bg-white text-gray-900 border-2 border-gray-100 rounded-2xl font-black flex items-center justify-center space-x-3 hover:border-gray-200 transition-all"
          >
            <MessageCircle size={20} />
            <span>Get Support</span>
          </Link>
        </div>

        <div className="bg-gray-50 rounded-3xl p-8 mb-10 border border-gray-100 text-left">
          <h4 className="text-sm font-black text-gray-900 mb-4 flex items-center space-x-2">
            <HelpCircle size={18} className="text-gray-400" />
            <span>Common Questions</span>
          </h4>
          <ul className="space-y-3">
            <li className="text-xs font-bold text-gray-500 flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-red-400 rounded-full mt-1.5 flex-shrink-0" />
              <span>Is my data safe? Yes, we use Stripe for secure processing.</span>
            </li>
            <li className="text-xs font-bold text-gray-500 flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-red-400 rounded-full mt-1.5 flex-shrink-0" />
              <span>Was I charged? No, if the process was cancelled, no funds were moved.</span>
            </li>
          </ul>
        </div>

        <div className="flex items-center justify-center space-x-2 text-gray-400">
          <Heart size={16} />
          <span className="text-[10px] font-black uppercase tracking-widest">We still appreciate your support</span>
        </div>
      </motion.div>
    </div>
  );
};

export default DonationCancel;
