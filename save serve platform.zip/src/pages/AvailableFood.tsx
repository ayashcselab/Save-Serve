import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { useAuth } from '../context/AuthContext';
import { foodService } from '../services/foodService';
import { FoodItem } from '../types';
import { Card, Badge, Button, Input } from '../components/UI';
import { Utensils, MapPin, Clock, Search, Filter, Loader2, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const AvailableFood: React.FC = () => {
  const { user, profile, isNGO } = useAuth();
  const [foodItems, setFoodItems] = useState<FoodItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [acceptingId, setAcceptingId] = useState<string | null>(null);

  useEffect(() => {
    const q = query(
      collection(db, 'foodItems'), 
      where('status', '==', 'Available')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as FoodItem));
      // Client-side sort
      items.sort((a, b) => {
        const timeA = a.createdAt?.toMillis() || 0;
        const timeB = b.createdAt?.toMillis() || 0;
        return timeB - timeA;
      });
      setFoodItems(items);
      setLoading(false);
    }, (error) => {
      console.error("Firestore Error in AvailableFood:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleAccept = async (food: FoodItem) => {
    if (!user || !profile || !food.id) return;
    setAcceptingId(food.id);
    try {
      await foodService.acceptPickup(food.id, user.uid, profile.name, food.restaurantId);
    } catch (error) {
      console.error('Error accepting food:', error);
    } finally {
      setAcceptingId(null);
    }
  };

  const filteredFood = foodItems.filter(item => 
    item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.restaurantName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Available Food</h1>
          <p className="text-slate-500">Browse real-time listings of surplus food from partner restaurants.</p>
        </div>
        
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-80">
            <Search className="absolute left-4 top-3 text-slate-400" size={18} />
            <Input 
              placeholder="Search by food, location..." 
              className="pl-12"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline" className="flex items-center gap-2">
            <Filter size={18} />
            Filter
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="animate-spin text-emerald-600" size={40} />
        </div>
      ) : filteredFood.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence>
            {filteredFood.map((item) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
              >
                <Card className="h-full flex flex-col group">
                  <div className="relative h-48 overflow-hidden">
                    {item.imageURL ? (
                      <img 
                        src={item.imageURL} 
                        alt={item.name} 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                      />
                    ) : (
                      <div className="w-full h-full bg-slate-100 flex items-center justify-center text-slate-300">
                        <Utensils size={48} />
                      </div>
                    )}
                    <div className="absolute top-4 right-4">
                      <Badge variant="success">Available</Badge>
                    </div>
                  </div>
                  
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="mb-4">
                      <h3 className="text-xl font-bold text-slate-900 mb-1">{item.name}</h3>
                      <p className="text-emerald-600 font-bold text-sm">{item.restaurantName}</p>
                    </div>

                    <div className="space-y-3 mb-6 flex-1">
                      <div className="flex items-center gap-3 text-slate-600">
                        <Utensils size={16} className="text-slate-400" />
                        <span className="text-sm font-medium">{item.quantity}</span>
                      </div>
                      <div className="flex items-center gap-3 text-slate-600">
                        <Clock size={16} className="text-slate-400" />
                        <span className="text-sm font-medium">{item.pickupTime}</span>
                      </div>
                      <div className="flex items-center gap-3 text-slate-600">
                        <MapPin size={16} className="text-slate-400" />
                        <span className="text-sm font-medium truncate">{item.location}</span>
                      </div>
                    </div>

                    {isNGO && (
                      <Button 
                        className="w-full rounded-xl py-3 flex items-center justify-center gap-2"
                        onClick={() => handleAccept(item)}
                        disabled={acceptingId === item.id}
                      >
                        {acceptingId === item.id ? (
                          <Loader2 className="animate-spin" size={20} />
                        ) : (
                          <CheckCircle2 size={20} />
                        )}
                        {acceptingId === item.id ? 'Accepting...' : 'Accept Pickup'}
                      </Button>
                    )}
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-3xl border border-slate-100">
          <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <Utensils size={40} className="text-slate-300" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">No food items found</h3>
          <p className="text-slate-500">Try adjusting your search or check back later.</p>
        </div>
      )}
    </div>
  );
};
