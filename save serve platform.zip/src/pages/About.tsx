import React from 'react';
import { motion } from 'motion/react';
import { Utensils, Users, Globe, ShieldCheck, Award } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen bg-white pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-24"
        >
          <h1 className="text-6xl font-black text-gray-900 tracking-tighter mb-6">Our Mission</h1>
          <p className="text-xl text-gray-500 max-w-3xl mx-auto font-bold leading-relaxed">
            Save & Serve is a technology-driven platform dedicated to bridging the gap between surplus food and those who need it most. 
            We empower restaurants to reduce waste and NGOs to increase their impact.
          </p>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-32">
          {[
            { icon: <Utensils size={32} />, title: 'Zero Waste', desc: 'We believe no edible food should ever end up in a landfill.' },
            { icon: <Users size={32} />, title: 'Community First', desc: 'Building strong networks between local businesses and social organizations.' },
            { icon: <Globe size={32} />, title: 'Global Impact', desc: 'Scaling our platform to solve hunger on a global scale.' }
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="p-8 rounded-[40px] bg-gray-50 border border-gray-100 group hover:bg-green-600 transition-all duration-500"
            >
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-green-600 mb-6 group-hover:scale-110 transition-transform">
                {item.icon}
              </div>
              <h3 className="text-2xl font-black text-gray-900 mb-4 group-hover:text-white transition-colors">{item.title}</h3>
              <p className="text-gray-500 font-bold group-hover:text-green-50 transition-colors">{item.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* Story */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-black text-gray-900 mb-8 tracking-tight">How it all started</h2>
            <div className="space-y-6 text-gray-600 font-bold leading-relaxed">
              <p>
                In 2024, we noticed a heartbreaking paradox: while millions go hungry every day, nearly 40% of all food produced is wasted. 
                Most of this waste happens at the retail and restaurant level due to logistical challenges.
              </p>
              <p>
                Save & Serve was born out of the need for a real-time, transparent, and efficient way to connect these two worlds. 
                By leveraging technology, we've made it possible for a restaurant to donate surplus food in seconds and for an NGO to pick it up in minutes.
              </p>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img 
              src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=800" 
              alt="Community Impact" 
              className="rounded-[48px] shadow-2xl"
              referrerPolicy="no-referrer"
            />
            <div className="absolute -bottom-10 -right-10 bg-green-600 p-10 rounded-[40px] text-white shadow-xl hidden md:block">
              <p className="text-4xl font-black mb-1">1M+</p>
              <p className="text-xs font-black uppercase tracking-widest opacity-80">Meals Rescued</p>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default About;
