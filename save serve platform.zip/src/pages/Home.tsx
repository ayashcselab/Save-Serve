import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Utensils, 
  Heart, 
  ArrowRight, 
  ShieldCheck, 
  Zap, 
  Users, 
  Globe, 
  Award, 
  TrendingUp, 
  Clock, 
  MapPin, 
  CheckCircle2,
  ChevronRight,
  Star,
  Quote,
  Package
} from 'lucide-react';
import { motion, useScroll, useTransform, AnimatePresence } from 'motion/react';
import { collection, onSnapshot, query, limit } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { FoodItem } from '../types';

const Home = () => {
  const [stats, setStats] = useState({
    meals: 12540,
    restaurants: 542,
    ngos: 218,
    cities: 12
  });

  const [recentDonations, setRecentDonations] = useState<FoodItem[]>([]);
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.2], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.2], [1, 0.9]);

  useEffect(() => {
    // Simulated live counter increment
    const interval = setInterval(() => {
      setStats(prev => ({
        ...prev,
        meals: prev.meals + Math.floor(Math.random() * 3)
      }));
    }, 5000);

    // Fetch a few recent donations for the "Live Feed" section
    const q = query(collection(db, 'foodItems'), limit(3));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as FoodItem));
      setRecentDonations(items);
    });

    return () => {
      clearInterval(interval);
      unsubscribe();
    };
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-white selection:bg-green-100 selection:text-green-900">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden bg-[#0A0A0A] text-white">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div 
            animate={{ 
              scale: [1, 1.2, 1],
              rotate: [0, 90, 0],
              opacity: [0.1, 0.2, 0.1]
            }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute -top-1/4 -left-1/4 w-[800px] h-[800px] bg-green-600/20 rounded-full blur-[120px]" 
          />
          <motion.div 
            animate={{ 
              scale: [1.2, 1, 1.2],
              rotate: [90, 0, 90],
              opacity: [0.1, 0.15, 0.1]
            }}
            transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
            className="absolute -bottom-1/4 -right-1/4 w-[600px] h-[600px] bg-emerald-600/20 rounded-full blur-[100px]" 
          />
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              style={{ opacity, scale }}
            >
              <div className="inline-flex items-center space-x-2 bg-white/5 border border-white/10 px-4 py-2 rounded-full mb-8 backdrop-blur-md">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                </span>
                <span className="text-xs font-black uppercase tracking-widest text-green-400">Live: {stats.meals.toLocaleString()} Meals Rescued</span>
              </div>

              <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.9] mb-8">
                SAVE <span className="text-green-500">FOOD</span><br />
                SERVE <span className="text-emerald-400 italic font-serif">HOPE</span>
              </h1>
              
              <p className="text-xl text-gray-400 mb-12 max-w-xl leading-relaxed font-medium">
                The world's most advanced logistics platform connecting surplus restaurant food with local NGOs in real-time. Zero waste. Zero hunger.
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-6">
                <Link 
                  to="/signup" 
                  className="group relative w-full sm:w-auto bg-green-600 text-white px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-green-500 transition-all overflow-hidden"
                >
                  <span className="relative z-10 flex items-center justify-center space-x-3">
                    <span>Join the Mission</span>
                    <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                  </span>
                  <motion.div 
                    className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"
                  />
                </Link>
                
                <Link 
                  to="/public-donations" 
                  className="w-full sm:w-auto px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest border border-white/20 hover:bg-white/5 transition-all flex items-center justify-center space-x-3"
                >
                  <Globe size={18} className="text-green-400" />
                  <span>Explore Live Map</span>
                </Link>
              </div>

              <div className="mt-16 flex items-center space-x-8 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
                <div className="flex flex-col">
                  <span className="text-2xl font-black">500+</span>
                  <span className="text-[10px] uppercase tracking-widest font-bold">Partners</span>
                </div>
                <div className="w-px h-8 bg-white/20" />
                <div className="flex flex-col">
                  <span className="text-2xl font-black">12</span>
                  <span className="text-[10px] uppercase tracking-widest font-bold">Cities</span>
                </div>
                <div className="w-px h-8 bg-white/20" />
                <div className="flex flex-col">
                  <span className="text-2xl font-black">24/7</span>
                  <span className="text-[10px] uppercase tracking-widest font-bold">Support</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8, rotate: 5 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
              className="relative hidden lg:block"
            >
              <div className="relative z-10 bg-gradient-to-br from-white/10 to-white/5 p-4 rounded-[40px] border border-white/10 backdrop-blur-2xl shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&q=80&w=1000" 
                  alt="Food Rescue" 
                  className="rounded-[32px] w-full h-[600px] object-cover"
                  referrerPolicy="no-referrer"
                />
                
                {/* Floating Stats Card */}
                <motion.div 
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -right-12 top-1/4 bg-white p-6 rounded-3xl shadow-2xl text-black border border-gray-100"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                      <TrendingUp className="text-green-600" size={24} />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Growth</p>
                      <p className="text-xl font-black">+124%</p>
                    </div>
                  </div>
                </motion.div>

                {/* Floating User Card */}
                <motion.div 
                  animate={{ y: [0, 10, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  className="absolute -left-12 bottom-1/4 bg-white p-6 rounded-3xl shadow-2xl text-black border border-gray-100"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center">
                      <Heart className="text-emerald-600" size={24} />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Impact</p>
                      <p className="text-xl font-black">2.4M kg</p>
                    </div>
                  </div>
                </motion.div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Live Impact Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            {[
              { label: "Meals Rescued", value: stats.meals.toLocaleString(), icon: <Utensils />, color: "text-green-600" },
              { label: "Partner Restaurants", value: stats.restaurants, icon: <Star />, color: "text-yellow-500" },
              { label: "Active NGOs", value: stats.ngos, icon: <Users />, color: "text-blue-600" },
              { label: "Cities Covered", value: stats.cities, icon: <Globe />, color: "text-purple-600" }
            ].map((stat, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="text-center group"
              >
                <div className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gray-50 flex items-center justify-center ${stat.color} group-hover:scale-110 transition-transform duration-300`}>
                  {React.cloneElement(stat.icon as React.ReactElement, { size: 32 })}
                </div>
                <h3 className="text-4xl font-black text-gray-900 mb-2">{stat.value}</h3>
                <p className="text-xs font-black uppercase tracking-widest text-gray-400">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Live Feed Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
            <div>
              <h2 className="text-sm font-black text-green-600 uppercase tracking-[0.3em] mb-4">Real-Time Impact</h2>
              <h3 className="text-5xl font-black text-gray-900 tracking-tighter leading-none">Live Rescue Feed</h3>
            </div>
            <Link 
              to="/public-donations" 
              className="flex items-center space-x-2 text-green-600 font-black uppercase tracking-widest text-xs hover:translate-x-2 transition-transform"
            >
              <span>View All Donations</span>
              <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <AnimatePresence mode="popLayout">
              {recentDonations.length > 0 ? (
                recentDonations.map((donation, idx) => (
                  <motion.div
                    key={donation.id}
                    initial={{ opacity: 0, scale: 0.9, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.9, y: -20 }}
                    transition={{ delay: idx * 0.1 }}
                    className="bg-white p-8 rounded-[32px] shadow-xl shadow-gray-200/50 border border-gray-100 relative overflow-hidden group"
                  >
                    <div className="absolute top-0 right-0 p-4">
                      <span className="bg-green-100 text-green-600 text-[10px] font-black px-2 py-1 rounded-full uppercase tracking-widest">
                        {donation.status}
                      </span>
                    </div>
                    <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center text-green-600 mb-6 group-hover:scale-110 transition-transform">
                      <Package size={24} />
                    </div>
                    <h4 className="text-xl font-black text-gray-900 mb-2 truncate">{donation.name}</h4>
                    <div className="flex items-center space-x-2 text-gray-400 text-xs font-bold mb-6">
                      <MapPin size={14} />
                      <span>{donation.location}</span>
                    </div>
                    <div className="pt-6 border-t border-gray-50 flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-6 h-6 bg-gray-900 rounded-lg flex items-center justify-center text-[10px] font-black text-white">
                          {donation.restaurantName.charAt(0)}
                        </div>
                        <span className="text-xs font-bold text-gray-600">{donation.restaurantName}</span>
                      </div>
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                        {donation.quantity}
                      </span>
                    </div>
                  </motion.div>
                ))
              ) : (
                [1,2,3].map(i => (
                  <div key={i} className="bg-white p-8 rounded-[32px] border border-gray-100 animate-pulse">
                    <div className="w-12 h-12 bg-gray-100 rounded-2xl mb-6" />
                    <div className="h-6 bg-gray-100 rounded-full w-3/4 mb-4" />
                    <div className="h-4 bg-gray-50 rounded-full w-1/2" />
                  </div>
                ))
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* How It Works - Visual Steps */}
      <section className="py-32 bg-gray-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-24">
            <h2 className="text-sm font-black text-green-600 uppercase tracking-[0.3em] mb-4">The Ecosystem</h2>
            <h3 className="text-5xl md:text-6xl font-black text-gray-900 tracking-tighter">How We Bridge The Gap</h3>
          </div>

          <div className="relative">
            {/* Connecting Line */}
            <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-200 -translate-y-1/2 hidden lg:block" />
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 relative">
              {[
                {
                  step: "01",
                  title: "Post Surplus",
                  desc: "Restaurants list available food with photos, quantity, and pickup time in under 30 seconds.",
                  icon: <Package className="text-white" size={32} />,
                  bg: "bg-green-600"
                },
                {
                  step: "02",
                  title: "NGO Match",
                  desc: "Our real-time engine notifies local NGOs. The first to accept starts the tracking process.",
                  icon: <Zap className="text-white" size={32} />,
                  bg: "bg-emerald-600"
                },
                {
                  step: "03",
                  title: "Live Rescue",
                  desc: "Full logistics tracking from pickup to distribution. Real-time ETA and status updates.",
                  icon: <TrendingUp className="text-white" size={32} />,
                  bg: "bg-blue-600"
                }
              ].map((item, idx) => (
                <motion.div 
                  key={idx}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.2 }}
                  className="relative bg-white p-10 rounded-[40px] shadow-xl shadow-gray-200/50 border border-gray-100 group hover:border-green-500 transition-colors"
                >
                  <div className={`w-20 h-20 ${item.bg} rounded-3xl flex items-center justify-center mb-8 shadow-lg shadow-gray-200 group-hover:scale-110 transition-transform duration-500`}>
                    {item.icon}
                  </div>
                  <span className="text-6xl font-black text-gray-100 absolute top-8 right-8 group-hover:text-green-50 transition-colors">{item.step}</span>
                  <h4 className="text-2xl font-black text-gray-900 mb-4">{item.title}</h4>
                  <p className="text-gray-500 leading-relaxed font-medium">{item.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Partners Marquee (Simulated) */}
      <section className="py-24 bg-white border-y border-gray-100 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
          <p className="text-center text-[10px] font-black uppercase tracking-[0.4em] text-gray-400">Trusted by World-Class Establishments</p>
        </div>
        <div className="flex space-x-12 animate-marquee whitespace-nowrap">
          {[1,2,3,4,5,6,7,8].map((i) => (
            <div key={i} className="flex items-center space-x-12 opacity-30 hover:opacity-100 transition-opacity cursor-default">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-900 rounded-xl" />
                <span className="text-xl font-black text-gray-900">PARTNER_{i}</span>
              </div>
              <Star className="text-gray-300" size={20} />
            </div>
          ))}
          {/* Duplicate for seamless loop */}
          {[1,2,3,4,5,6,7,8].map((i) => (
            <div key={`dup-${i}`} className="flex items-center space-x-12 opacity-30 hover:opacity-100 transition-opacity cursor-default">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gray-900 rounded-xl" />
                <span className="text-xl font-black text-gray-900">PARTNER_{i}</span>
              </div>
              <Star className="text-gray-300" size={20} />
            </div>
          ))}
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-32 bg-[#0A0A0A] text-white relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <div>
              <Quote size={64} className="text-green-500 mb-8 opacity-50" />
              <h3 className="text-4xl md:text-5xl font-black tracking-tighter leading-tight mb-12">
                "Save & Serve hasn't just reduced our waste; it's transformed our relationship with the community. We're now part of a global solution."
              </h3>
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-green-600 rounded-2xl overflow-hidden">
                  <img src="https://i.pravatar.cc/150?u=restaurant_owner" alt="Owner" />
                </div>
                <div>
                  <p className="text-xl font-black">Marcus Chen</p>
                  <p className="text-sm text-green-500 font-bold uppercase tracking-widest">Executive Chef, The Green Bistro</p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-6">
                <div className="bg-white/5 p-8 rounded-[32px] border border-white/10 backdrop-blur-md">
                  <p className="text-3xl font-black text-green-400 mb-2">98%</p>
                  <p className="text-xs font-bold uppercase tracking-widest text-gray-400">Waste Reduction</p>
                </div>
                <div className="bg-white/5 p-8 rounded-[32px] border border-white/10 backdrop-blur-md">
                  <p className="text-3xl font-black text-blue-400 mb-2">15m</p>
                  <p className="text-xs font-bold uppercase tracking-widest text-gray-400">Avg. Response Time</p>
                </div>
              </div>
              <div className="space-y-6 pt-12">
                <div className="bg-white/5 p-8 rounded-[32px] border border-white/10 backdrop-blur-md">
                  <p className="text-3xl font-black text-emerald-400 mb-2">5.2k</p>
                  <p className="text-xs font-bold uppercase tracking-widest text-gray-400">NGO Network</p>
                </div>
                <div className="bg-white/5 p-8 rounded-[32px] border border-white/10 backdrop-blur-md">
                  <p className="text-3xl font-black text-purple-400 mb-2">Zero</p>
                  <p className="text-xs font-bold uppercase tracking-widest text-gray-400">Platform Fees</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 bg-green-600 relative overflow-hidden">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
          className="absolute -top-1/2 -right-1/4 w-[1000px] h-[1000px] border-[100px] border-white/5 rounded-full"
        />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter mb-12 max-w-4xl mx-auto">
            Ready to make a real difference?
          </h2>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
            <Link 
              to="/signup" 
              className="w-full sm:w-auto bg-white text-green-600 px-12 py-6 rounded-3xl font-black text-lg uppercase tracking-widest hover:bg-gray-100 transition-all shadow-2xl"
            >
              Start Donating
            </Link>
            <Link 
              to="/signup?role=NGO" 
              className="w-full sm:w-auto bg-green-700 text-white px-12 py-6 rounded-3xl font-black text-lg uppercase tracking-widest hover:bg-green-800 transition-all border border-white/10"
            >
              Register as NGO
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0A0A0A] text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-24">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-8">
                <div className="w-12 h-12 bg-green-600 rounded-2xl flex items-center justify-center">
                  <Utensils className="text-white" size={24} />
                </div>
                <span className="text-2xl font-black tracking-tighter">SAVE & SERVE</span>
              </div>
              <p className="text-gray-500 max-w-md leading-relaxed font-medium text-lg">
                Building the digital infrastructure for a zero-waste world. Join thousands of restaurants and NGOs in the fight against hunger.
              </p>
            </div>
            <div>
              <h4 className="text-xs font-black uppercase tracking-widest text-gray-400 mb-8">Platform</h4>
              <ul className="space-y-4 text-gray-500 font-bold">
                <li><Link to="/public-donations" className="hover:text-green-500 transition-colors">Live Map</Link></li>
                <li><Link to="/signup" className="hover:text-green-500 transition-colors">For Restaurants</Link></li>
                <li><Link to="/signup" className="hover:text-green-500 transition-colors">For NGOs</Link></li>
                <li><Link to="/login" className="hover:text-green-500 transition-colors">Dashboard</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-xs font-black uppercase tracking-widest text-gray-400 mb-8">Company</h4>
              <ul className="space-y-4 text-gray-500 font-bold">
                <li><a href="#" className="hover:text-green-500 transition-colors">Our Story</a></li>
                <li><a href="#" className="hover:text-green-500 transition-colors">Impact Report</a></li>
                <li><a href="#" className="hover:text-green-500 transition-colors">Privacy</a></li>
                <li><a href="#" className="hover:text-green-500 transition-colors">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8">
            <p className="text-gray-600 text-sm font-bold">© 2026 Save & Serve. All rights reserved.</p>
            <div className="flex space-x-6">
              {['Twitter', 'Instagram', 'LinkedIn'].map(social => (
                <a key={social} href="#" className="text-gray-600 hover:text-white transition-colors text-sm font-bold uppercase tracking-widest">{social}</a>
              ))}
            </div>
          </div>
        </div>
      </footer>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
      `}} />
    </div>
  );
};

export default Home;
