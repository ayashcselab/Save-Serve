import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db } from '../firebase/firebase';
import { Button, Input, Card } from '../components/UI';
import { Utensils, HandHeart, Mail, Lock, User, MapPin, Phone } from 'lucide-react';

export const AuthPage: React.FC<{ mode: 'login' | 'signup' }> = ({ mode }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'restaurant' | 'ngo'>('restaurant');
  const [location, setLocation] = useState('');
  const [contact, setContact] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (mode === 'signup') {
        const { user } = await createUserWithEmailAndPassword(auth, email, password);
        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          name,
          email,
          role,
          location,
          contact,
          createdAt: serverTimestamp(),
        });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      navigate('/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4 bg-slate-50">
      <Card className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-slate-900">
            {mode === 'signup' ? 'Create Account' : 'Welcome Back'}
          </h2>
          <p className="text-slate-500 mt-2">
            {mode === 'signup' ? 'Join our food rescue network' : 'Login to your dashboard'}
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-rose-50 border border-rose-100 text-rose-600 rounded-xl text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {mode === 'signup' && (
            <>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <button
                  type="button"
                  onClick={() => setRole('restaurant')}
                  className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${
                    role === 'restaurant' ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-slate-100 text-slate-500'
                  }`}
                >
                  <Utensils size={24} />
                  <span className="text-sm font-bold">Restaurant</span>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('ngo')}
                  className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-2 ${
                    role === 'ngo' ? 'border-emerald-500 bg-emerald-50 text-emerald-700' : 'border-slate-100 text-slate-500'
                  }`}
                >
                  <HandHeart size={24} />
                  <span className="text-sm font-bold">NGO</span>
                </button>
              </div>

              <div className="relative">
                <User className="absolute left-4 top-3 text-slate-400" size={18} />
                <Input
                  placeholder="Full Name / Organization Name"
                  className="pl-12"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>

              <div className="relative">
                <MapPin className="absolute left-4 top-3 text-slate-400" size={18} />
                <Input
                  placeholder="Location / Address"
                  className="pl-12"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                />
              </div>

              <div className="relative">
                <Phone className="absolute left-4 top-3 text-slate-400" size={18} />
                <Input
                  placeholder="Contact Number"
                  className="pl-12"
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  required
                />
              </div>
            </>
          )}

          <div className="relative">
            <Mail className="absolute left-4 top-3 text-slate-400" size={18} />
            <Input
              type="email"
              placeholder="Email Address"
              className="pl-12"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute left-4 top-3 text-slate-400" size={18} />
            <Input
              type="password"
              placeholder="Password"
              className="pl-12"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <Button className="w-full py-3 rounded-2xl text-lg" disabled={loading}>
            {loading ? 'Processing...' : mode === 'signup' ? 'Create Account' : 'Login'}
          </Button>
        </form>

        <div className="mt-8 text-center text-slate-500">
          {mode === 'signup' ? (
            <p>Already have an account? <Link to="/login" className="text-emerald-600 font-bold hover:underline">Login</Link></p>
          ) : (
            <p>Don't have an account? <Link to="/signup" className="text-emerald-600 font-bold hover:underline">Sign Up</Link></p>
          )}
        </div>
      </Card>
    </div>
  );
};
