import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy, updateDoc, doc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { useAuth } from '../context/AuthContext';
import { foodService } from '../services/foodService';
import { Card, Badge, Button } from '../components/UI';
import { HandHeart, MapPin, Clock, CheckCircle2, Truck, PackageCheck, Loader2, Timer } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { FoodItem, FoodStatus } from '../types';

export const MyPickups: React.FC = () => {
  const { profile } = useAuth();
  const [pickups, setPickups] = useState<FoodItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;

    const q = query(
      collection(db, 'foodItems'), 
      where('ngoId', '==', profile.uid),
      where('status', 'in', ['Accepted', 'On The Way', 'Collected'])
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as FoodItem[];
      
      // Client-side sort
      items.sort((a, b) => {
        const timeA = a.updatedAt?.toMillis?.() || 0;
        const timeB = b.updatedAt?.toMillis?.() || 0;
        return timeB - timeA;
      });

      setPickups(items);
      setLoading(false);
    }, (error) => {
      console.error("Firestore Error in MyPickups:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [profile]);

  const handleStatusUpdate = async (item: FoodItem, nextStatus: FoodStatus) => {
    if (!profile) return;
    setProcessingId(item.id);
    try {
      const updateData: any = {
        status: nextStatus,
        updatedAt: serverTimestamp(),
        statusHistory: [
          ...(item.statusHistory || []),
          {
            status: nextStatus,
            timestamp: new Date(),
            updatedBy: profile.uid,
            notes: `Status updated to ${nextStatus}`
          }
        ]
      };

      if (nextStatus === 'On The Way') {
        updateData.pickupStartedAt = serverTimestamp();
      } else if (nextStatus === 'Collected') {
        updateData.receivedAt = serverTimestamp();
      } else if (nextStatus === 'Distributed') {
        updateData.distributedAt = serverTimestamp();
      }

      await updateDoc(doc(db, 'foodItems', item.id), updateData);
    } catch (error) {
      console.error('Error updating status:', error);
    } finally {
      setProcessingId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-10">
        <h1 className="text-3xl font-black text-gray-900 uppercase tracking-tight">Active Logistics</h1>
        <p className="text-gray-500 font-medium">Track and manage your active food collection and distribution tasks.</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="animate-spin text-green-600" size={40} />
        </div>
      ) : pickups.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <AnimatePresence>
            {pickups.map((item) => (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
              >
                <Card className="p-6 border-gray-100 shadow-sm hover:shadow-md transition-shadow rounded-3xl">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <Badge variant={item.status === 'Accepted' ? 'warning' : 'info'} className="uppercase tracking-widest text-[10px] font-black">
                        {item.status}
                      </Badge>
                      <h3 className="text-xl font-black text-gray-900 mt-2">{item.name}</h3>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">{item.restaurantName}</p>
                    </div>
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                      item.status === 'Accepted' ? 'bg-blue-50 text-blue-600' : 
                      item.status === 'On The Way' ? 'bg-yellow-50 text-yellow-600' : 
                      'bg-purple-50 text-purple-600'
                    }`}>
                      {item.status === 'Accepted' ? <Clock size={24} /> : 
                       item.status === 'On The Way' ? <Truck size={24} /> : 
                       <PackageCheck size={24} />}
                    </div>
                  </div>

                  <div className="space-y-4 mb-8">
                    <div className="flex items-center gap-3 text-gray-600">
                      <MapPin size={18} className="text-green-500" />
                      <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Pickup Location</p>
                        <p className="text-sm font-bold">{item.location}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-gray-600">
                      <Timer size={18} className="text-green-500" />
                      <div>
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-wider">Last Updated</p>
                        <p className="text-sm font-bold">
                          {item.updatedAt?.toDate ? item.updatedAt.toDate().toLocaleString() : 'Just now'}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    {item.status === 'Accepted' && (
                      <Button 
                        className="flex-1 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest bg-blue-600 hover:bg-blue-700"
                        onClick={() => handleStatusUpdate(item, 'On The Way')}
                        disabled={processingId === item.id}
                      >
                        {processingId === item.id ? <Loader2 className="animate-spin" size={18} /> : <Truck size={18} />}
                        <span>Start Pickup</span>
                      </Button>
                    )}
                    {item.status === 'On The Way' && (
                      <Button 
                        className="flex-1 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest bg-yellow-600 hover:bg-yellow-700"
                        onClick={() => handleStatusUpdate(item, 'Collected')}
                        disabled={processingId === item.id}
                      >
                        {processingId === item.id ? <Loader2 className="animate-spin" size={18} /> : <CheckCircle2 size={18} />}
                        <span>Mark as Collected</span>
                      </Button>
                    )}
                    {item.status === 'Collected' && (
                      <Button 
                        className="flex-1 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest bg-green-600 hover:bg-green-700"
                        onClick={() => handleStatusUpdate(item, 'Distributed')}
                        disabled={processingId === item.id}
                      >
                        {processingId === item.id ? <Loader2 className="animate-spin" size={18} /> : <HandHeart size={18} />}
                        <span>Mark as Distributed</span>
                      </Button>
                    )}
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-[40px] border border-gray-100 shadow-sm">
          <div className="w-24 h-24 bg-gray-50 rounded-[2rem] flex items-center justify-center mx-auto mb-6">
            <HandHeart size={48} className="text-gray-200" />
          </div>
          <h3 className="text-2xl font-black text-gray-900 mb-2 uppercase tracking-tight">No active pickups</h3>
          <p className="text-gray-500 font-medium max-w-xs mx-auto">Accept some food donations from the dashboard to see them here.</p>
        </div>
      )}
    </div>
  );
};
