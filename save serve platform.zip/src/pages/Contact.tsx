import React from 'react';
import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Send, Globe, MessageCircle } from 'lucide-react';
import { toast } from 'sonner';

const Contact = () => {
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [isSending, setIsSending] = React.useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    console.log('Form submitted:', formData);
    toast.success('Message sent! We will get back to you soon.');
    
    // Clear form after submission
    setFormData({
      name: '',
      email: '',
      subject: '',
      message: ''
    });
    setIsSending(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-20"
        >
          <h1 className="text-6xl font-black text-gray-900 tracking-tighter mb-6">Get in Touch</h1>
          <p className="text-xl text-gray-500 max-w-2xl mx-auto font-bold leading-relaxed">
            Have questions or want to partner with us? We'd love to hear from you. 
            Our team is here to help you make an impact.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Contact Info */}
          <div className="space-y-8">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white p-10 rounded-[48px] shadow-xl shadow-gray-200/50 border border-gray-100 hover:shadow-2xl transition-all duration-500"
            >
              <h3 className="text-2xl font-black text-gray-900 mb-8">Contact Information</h3>
              <div className="space-y-8">
                {[
                  { icon: <Mail />, label: 'Email Us', value: 'hello@saveandserve.org' },
                  { icon: <Phone />, label: 'Call Us', value: '+1 (555) 123-4567' },
                  { icon: <MapPin />, label: 'Visit Us', value: '123 Impact Way, San Francisco, CA' }
                ].map((item, i) => (
                  <div key={i} className="flex items-center space-x-6 group">
                    <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center text-green-600 group-hover:bg-green-600 group-hover:text-white transition-all duration-300">
                      {item.icon}
                    </div>
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">{item.label}</p>
                      <p className="text-lg font-black text-gray-900">{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-12 pt-12 border-t border-gray-50 flex space-x-4">
                {[<Globe />, <MessageCircle />].map((icon, i) => (
                  <button key={i} className="w-12 h-12 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 hover:bg-gray-900 hover:text-white transition-all">
                    {icon}
                  </button>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Contact Form */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gray-900 p-12 rounded-[48px] text-white shadow-2xl hover:shadow-green-500/10 transition-all duration-500 border border-white/5"
          >
            <h3 className="text-2xl font-black mb-8">Send a Message</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest opacity-60">Full Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-6 py-4 bg-white/10 border-none rounded-2xl font-bold text-white focus:ring-2 focus:ring-green-500 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest opacity-60">Email Address</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-6 py-4 bg-white/10 border-none rounded-2xl font-bold text-white focus:ring-2 focus:ring-green-500 transition-all"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-60">Subject</label>
                <input
                  type="text"
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-6 py-4 bg-white/10 border-none rounded-2xl font-bold text-white focus:ring-2 focus:ring-green-500 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest opacity-60">Message</label>
                <textarea
                  rows={4}
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full px-6 py-4 bg-white/10 border-none rounded-2xl font-bold text-white focus:ring-2 focus:ring-green-500 transition-all resize-none"
                />
              </div>
              <button
                type="submit"
                disabled={isSending}
                className="w-full py-6 bg-green-600 text-white rounded-2xl font-black text-lg flex items-center justify-center space-x-3 hover:bg-green-700 hover:scale-[1.02] active:scale-[0.98] transition-all group disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-green-600/20"
              >
                <span>{isSending ? 'Sending Message...' : 'Send Message'}</span>
                {!isSending && <Send size={20} className="group-hover:translate-x-2 group-hover:-translate-y-2 transition-transform" />}
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
