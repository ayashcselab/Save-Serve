import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { 
  Plus, 
  Utensils, 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  Users,
  Calendar,
  ChevronRight,
  ArrowUpRight,
  Package,
  Heart,
  UtensilsCrossed,
  LayoutDashboard,
  History,
  Timer,
  AlertCircle,
  MapPin,
  User
} from 'lucide-react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  orderBy,
  Timestamp,
  updateDoc,
  doc,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { useAuth } from '../context/AuthContext';
import FoodCard from '../components/FoodCard';
import AddFoodModal from '../components/AddFoodModal';
import { format, startOfDay, startOfWeek, startOfMonth, startOfYear, isAfter, differenceInMinutes } from 'date-fns';
import { handleFirestoreError, OperationType } from '../firebase/errorHandler';
import { FoodItem, FoodStatus } from '../types';

const RestaurantDashboard = () => {
  const { user, profile } = useAuth();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [foodItems, setFoodItems] = useState<FoodItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'active' | 'history' | 'analytics'>('active');

  useEffect(() => {
    if (!user || !profile) return;

    let q;
    if (profile.role === 'Admin') {
      q = query(
        collection(db, 'foodItems'),
        where('isDeleted', '==', false)
      );
    } else {
      q = query(
        collection(db, 'foodItems'),
        where('restaurantId', '==', user.uid),
        where('isDeleted', '==', false)
      );
    }

    const unsubscribe = onSnapshot(q as any, (snapshot: any) => {
      const items = snapshot.docs.map((doc: any) => ({
        id: doc.id,
        ...doc.data()
      })) as FoodItem[];
      
      // Client-side sorting to avoid index requirement
      items.sort((a, b) => {
        const timeA = a.createdAt?.toMillis?.() || 0;
        const timeB = b.createdAt?.toMillis?.() || 0;
        return timeB - timeA;
      });
      
      setFoodItems(items);
      setLoading(false);

      // Auto-expiry check
      const now = new Date();
      items.forEach(async (item) => {
        if (item.status === 'Available') {
          const pickupTime = item.pickupTime?.toDate ? item.pickupTime.toDate() : new Date(item.pickupTime);
          if (isAfter(now, pickupTime)) {
            try {
              await updateDoc(doc(db, 'foodItems', item.id), {
                status: 'Expired',
                updatedAt: serverTimestamp(),
                statusHistory: [
                  ...(item.statusHistory || []),
                  {
                    status: 'Expired',
                    timestamp: new Date(),
                    updatedBy: 'system',
                    notes: 'Food donation expired'
                  }
                ]
              });
            } catch (e) {
              console.error("Error expiring item:", e);
            }
          }
        }
      });
    }, (error: any) => {
      console.error("Error fetching food items:", error);
      if (error.code === 'failed-precondition') {
        console.warn("Missing index for foodItems query. Please create it using the link in the console.");
        if (unsubscribe) unsubscribe();
      } else {
        handleFirestoreError(error, OperationType.LIST, 'foodItems');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const stats = useMemo(() => {
    const now = new Date();
    const today = startOfDay(now);
    const week = startOfWeek(now);
    const month = startOfMonth(now);
    const year = startOfYear(now);

    return foodItems.reduce((acc, item) => {
      const createdDate = item.createdAt?.toDate ? item.createdAt.toDate() : new Date();
      
      acc.totalDonations++;
      if (['Available', 'Accepted', 'On The Way'].includes(item.status)) {
        acc.activeDonations++;
      } else if (['Collected', 'Distributed'].includes(item.status)) {
        acc.completedDonations++;
      } else if (item.status === 'Expired') {
        acc.expiredDonations++;
      }

      // Estimate people fed
      const qty = parseInt(item.quantity) || 0;
      acc.peopleFed += qty * 3;

      if (isAfter(createdDate, today)) acc.daily++;
      if (isAfter(createdDate, week)) acc.weekly++;
      if (isAfter(createdDate, month)) acc.monthly++;
      if (isAfter(createdDate, year)) acc.yearly++;

      // Rescue Time Calculation (Posted to Collected)
      if (item.createdAt && item.receivedAt) {
        const start = item.createdAt.toDate ? item.createdAt.toDate() : new Date(item.createdAt);
        const end = item.receivedAt.toDate ? item.receivedAt.toDate() : new Date(item.receivedAt);
        acc.totalRescueTime += differenceInMinutes(end, start);
        acc.rescueCount++;
      }

      return acc;
    }, {
      totalDonations: 0,
      activeDonations: 0,
      completedDonations: 0,
      expiredDonations: 0,
      peopleFed: 0,
      daily: 0,
      weekly: 0,
      monthly: 0,
      yearly: 0,
      totalRescueTime: 0,
      rescueCount: 0
    });
  }, [foodItems]);

  const avgRescueTime = stats.rescueCount > 0 ? Math.round(stats.totalRescueTime / stats.rescueCount) : 0;

  const activeItems = foodItems.filter(item => ['Available', 'Accepted', 'On The Way'].includes(item.status));
  const historyItems = foodItems.filter(item => ['Collected', 'Distributed', 'Expired'].includes(item.status));

  return (
    <div className="min-h-screen bg-gray-50/50 pb-20">
      {/* Header Section */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div className="flex items-center gap-6">
              <div className="w-20 h-20 bg-orange-100 rounded-3xl flex items-center justify-center text-orange-600 overflow-hidden border-4 border-white shadow-xl">
                {profile?.photoURL ? (
                  <img 
                    src={profile.photoURL} 
                    alt={profile.name} 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <Utensils size={32} />
                )}
              </div>
              <div>
                <h1 className="text-3xl font-black text-gray-900 tracking-tight uppercase">
                  {profile?.name || 'Restaurant'} Dashboard
                </h1>
                <div className="flex flex-wrap items-center gap-4 mt-2">
                  <p className="text-gray-500 flex items-center gap-2 font-bold text-sm">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                    Impact: Fed approx. <span className="font-black text-gray-900">{stats.peopleFed}</span> people
                  </p>
                  {profile?.location && (
                    <p className="text-gray-400 flex items-center gap-2 font-bold text-sm">
                      <MapPin className="w-4 h-4" />
                      {profile.location}
                    </p>
                  )}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link 
                to="/profile"
                className="inline-flex items-center justify-center px-6 py-4 border border-gray-200 text-sm font-black rounded-2xl text-gray-600 bg-white hover:bg-gray-50 transition-all active:scale-95 gap-2 uppercase tracking-widest"
              >
                <User size={18} />
                Profile
              </Link>
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="inline-flex items-center justify-center px-8 py-4 border border-transparent text-sm font-black rounded-2xl text-white bg-orange-600 hover:bg-orange-700 shadow-xl shadow-orange-200 transition-all active:scale-95 gap-2 uppercase tracking-widest"
              >
                <Plus className="w-5 h-5" />
                Post New Food
              </button>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
            {[
              { label: 'Active Posts', value: stats.activeDonations, icon: Clock, color: 'text-orange-600', bg: 'bg-orange-50' },
              { label: 'Total Rescued', value: stats.completedDonations, icon: CheckCircle2, color: 'text-green-600', bg: 'bg-green-50' },
              { label: 'Avg Rescue Time', value: `${avgRescueTime}m`, icon: Timer, color: 'text-blue-600', bg: 'bg-blue-50' },
              { label: 'Expired', value: stats.expiredDonations, icon: AlertCircle, color: 'text-red-600', bg: 'bg-red-50' },
            ].map((stat, i) => (
              <div key={i} className={`${stat.bg} p-5 rounded-3xl border border-white shadow-sm hover:shadow-md transition-shadow`}>
                <div className="flex items-center justify-between mb-3">
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  <ArrowUpRight className="w-4 h-4 text-gray-300" />
                </div>
                <div className="text-3xl font-black text-gray-900">{stat.value}</div>
                <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 mb-8 bg-white p-1.5 rounded-2xl border border-gray-200 w-fit shadow-sm">
          {[
            { id: 'active', label: 'Live Tracking', icon: Utensils },
            { id: 'history', label: 'History Log', icon: History },
            { id: 'analytics', label: 'Performance', icon: TrendingUp },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl text-[11px] font-black uppercase tracking-widest transition-all ${
                activeTab === tab.id
                  ? 'bg-gray-900 text-white shadow-lg'
                  : 'text-gray-400 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        {activeTab === 'active' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {activeItems.length > 0 ? (
              activeItems.map((item) => (
                <FoodCard key={item.id} item={item} showRestaurant={false} userRole="Restaurant" />
              ))
            ) : (
              <div className="col-span-full bg-white rounded-[2.5rem] border-2 border-dashed border-gray-200 p-20 text-center">
                <div className="bg-gray-50 w-24 h-24 rounded-[2rem] flex items-center justify-center mx-auto mb-6">
                  <Package className="w-12 h-12 text-gray-200" />
                </div>
                <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tight">No active donations</h3>
                <p className="text-gray-500 mt-2 max-w-xs mx-auto font-medium">
                  Your kitchen is quiet! Start a new donation to help those in need.
                </p>
                <button
                  onClick={() => setIsAddModalOpen(true)}
                  className="mt-8 px-8 py-3 bg-orange-600 text-white rounded-xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all flex items-center gap-2 mx-auto"
                >
                  Post Food Now <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {historyItems.length > 0 ? (
              historyItems.map((item) => (
                <FoodCard key={item.id} item={item} showRestaurant={false} userRole="Restaurant" />
              ))
            ) : (
              <div className="col-span-full text-center py-20 bg-white rounded-3xl border border-gray-100">
                <History className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                <p className="text-gray-500 font-medium">No donation history found yet.</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-8">
            {/* Detailed Analytics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { label: 'Today', value: stats.daily, trend: '+12%', sub: 'Donations today' },
                { label: 'This Week', value: stats.weekly, trend: '+5%', sub: 'Donations this week' },
                { label: 'This Month', value: stats.monthly, trend: '+18%', sub: 'Donations this month' },
                { label: 'Total Impact', value: stats.peopleFed, trend: '+24%', sub: 'Estimated people fed' },
              ].map((item, i) => (
                <div key={i} className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm hover:border-orange-100 transition-colors">
                  <div className="flex justify-between items-start mb-4">
                    <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{item.label}</div>
                    <div className="text-[10px] font-black text-green-600 bg-green-50 px-2 py-1 rounded-lg">
                      {item.trend}
                    </div>
                  </div>
                  <div className="text-4xl font-black text-gray-900">{item.value}</div>
                  <div className="text-[10px] text-gray-400 mt-2 font-bold uppercase tracking-widest">{item.sub}</div>
                </div>
              ))}
            </div>

            {/* Performance Chart */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-sm">
                <div className="flex items-center justify-between mb-10">
                  <div>
                    <h3 className="text-xl font-black text-gray-900 uppercase tracking-tight">Rescue Velocity</h3>
                    <p className="text-sm text-gray-500 font-medium">Average time from posting to collection</p>
                  </div>
                  <div className="flex items-center gap-2 bg-gray-50 p-2 rounded-xl">
                    <Timer className="w-5 h-5 text-orange-500" />
                    <span className="text-lg font-black text-gray-900">{avgRescueTime}m</span>
                  </div>
                </div>
                
                <div className="h-64 flex items-end justify-between gap-4 px-4">
                  {[45, 60, 35, 80, 55, 90, 70].map((height, i) => (
                    <div key={i} className="flex-1 flex flex-col items-center gap-4 group">
                      <div className="w-full relative flex items-end justify-center">
                        <div 
                          className="w-full bg-orange-50 rounded-t-2xl transition-all duration-500 group-hover:bg-orange-100"
                          style={{ height: `${height}%` }}
                        />
                        <div 
                          className="absolute bottom-0 w-full bg-orange-500 rounded-t-2xl transition-all duration-700 opacity-0 group-hover:opacity-100"
                          style={{ height: `${height * 0.3}%` }}
                        />
                      </div>
                      <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                        {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i]}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gray-900 p-8 rounded-[2.5rem] shadow-2xl text-white relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-xl font-black uppercase tracking-tight mb-8">Efficiency Score</h3>
                  <div className="flex flex-col items-center justify-center py-6">
                    <div className="relative w-40 h-40 flex items-center justify-center">
                      <svg className="w-full h-full transform -rotate-90">
                        <circle
                          cx="80"
                          cy="80"
                          r="70"
                          fill="transparent"
                          stroke="rgba(255,255,255,0.1)"
                          strokeWidth="12"
                        />
                        <circle
                          cx="80"
                          cy="80"
                          r="70"
                          fill="transparent"
                          stroke="#F97316"
                          strokeWidth="12"
                          strokeDasharray={440}
                          strokeDashoffset={440 - (440 * 0.92)}
                          strokeLinecap="round"
                          className="transition-all duration-1000"
                        />
                      </svg>
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-4xl font-black">92%</span>
                        <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Optimal</span>
                      </div>
                    </div>
                    <p className="mt-8 text-center text-sm text-gray-400 font-medium">
                      Your rescue efficiency is in the top <span className="text-orange-500 font-bold">5%</span> of all partners.
                    </p>
                  </div>
                </div>
                <div className="absolute -top-20 -left-20 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl" />
              </div>
            </div>
          </div>
        )}
      </div>

      <AddFoodModal 
        isOpen={isAddModalOpen} 
        onClose={() => setIsAddModalOpen(false)} 
      />
    </div>
  );
};

export default RestaurantDashboard;
