import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, DollarSign, ShieldCheck, Globe, ArrowRight, CheckCircle2, Loader2, CreditCard } from 'lucide-react';
import { db } from '../firebase/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { toast } from 'sonner';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import PaymentForm from '../components/PaymentForm';

// Initialize Stripe
const stripePromise = loadStripe((import.meta as any).env.VITE_STRIPE_PUBLISHABLE_KEY || '');

const Donate = () => {
  const [amount, setAmount] = useState<string>('25');
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState<'amount' | 'payment'>('amount');
  const [donorInfo, setDonorInfo] = useState({ name: '', email: '' });
  const [clientSecret, setClientSecret] = useState<string | null>(null);

  const handleProceedToPayment = async () => {
    const finalAmount = parseFloat(amount);
    
    if (!finalAmount || finalAmount <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    if (!donorInfo.email) {
      toast.error('Please enter your email');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: finalAmount, donorEmail: donorInfo.email }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to initialize payment');
      }

      const data = await response.json();
      setClientSecret(data.clientSecret);
      setStep('payment');
    } catch (error: any) {
      console.error('Payment initialization error:', error);
      toast.error(error.message || 'Failed to initiate donation');
    } finally {
      setLoading(false);
    }
  };

  const handleSuccess = () => {
    setStep('amount');
    setAmount('25');
    setDonorInfo({ name: '', email: '' });
    setClientSecret(null);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] pt-24 pb-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center justify-center w-20 h-20 bg-red-100 text-red-600 rounded-3xl mb-6 shadow-xl shadow-red-100">
            <Heart size={40} fill="currentColor" />
          </div>
          <h1 className="text-5xl md:text-7xl font-black text-gray-900 tracking-tighter mb-4">Support Our Mission</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto font-medium">
            Your contribution helps us rescue more food and serve more people in need. 
            Every dollar counts towards a zero-hunger future.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Donation Form */}
          <div className="md:col-span-2 space-y-8">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white p-8 md:p-12 rounded-[48px] shadow-2xl shadow-gray-200/50 border border-gray-100 relative overflow-hidden"
            >
              <AnimatePresence mode="wait">
                {step === 'amount' ? (
                  <motion.div
                    key="amount-step"
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    className="space-y-8"
                  >
                    <div>
                      <h3 className="text-2xl font-black text-gray-900 mb-6 flex items-center space-x-3">
                        <DollarSign className="text-green-600" />
                        <span>Select Amount</span>
                      </h3>
                      <div className="grid grid-cols-3 gap-4 mb-8">
                        {[10, 25, 50, 100, 250, 500].map((val) => (
                          <button
                            key={val}
                            onClick={() => setAmount(val.toString())}
                            className={`py-5 rounded-2xl font-black transition-all text-lg ${
                              amount === val.toString()
                                ? 'bg-green-600 text-white shadow-xl shadow-green-200 scale-105' 
                                : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                            }`}
                          >
                            ${val}
                          </button>
                        ))}
                      </div>

                      <div className="relative mb-8">
                        <div className="absolute inset-y-0 left-0 pl-6 flex items-center pointer-events-none">
                          <DollarSign size={24} className="text-gray-400" />
                        </div>
                        <input
                          type="number"
                          placeholder="Custom Amount"
                          value={amount}
                          onChange={(e) => setAmount(e.target.value)}
                          className="block w-full pl-16 pr-6 py-6 bg-gray-50 border-none rounded-2xl font-black text-2xl text-gray-900 focus:ring-4 focus:ring-green-500/10 transition-all placeholder:text-gray-300"
                        />
                      </div>
                    </div>

                    <div>
                      <h3 className="text-2xl font-black text-gray-900 mb-6 flex items-center space-x-3">
                        <Globe className="text-blue-600" />
                        <span>Your Information</span>
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                        <input
                          type="text"
                          placeholder="Full Name (Optional)"
                          value={donorInfo.name}
                          onChange={(e) => setDonorInfo({ ...donorInfo, name: e.target.value })}
                          className="block w-full px-6 py-5 bg-gray-50 border-none rounded-2xl font-bold text-gray-900 focus:ring-4 focus:ring-green-500/10 transition-all"
                        />
                        <input
                          type="email"
                          placeholder="Email Address"
                          required
                          value={donorInfo.email}
                          onChange={(e) => setDonorInfo({ ...donorInfo, email: e.target.value })}
                          className="block w-full px-6 py-5 bg-gray-50 border-none rounded-2xl font-bold text-gray-900 focus:ring-4 focus:ring-green-500/10 transition-all"
                        />
                      </div>
                    </div>

                    <button
                      onClick={handleProceedToPayment}
                      disabled={loading}
                      className="w-full py-6 bg-gray-900 text-white rounded-2xl font-black text-xl flex items-center justify-center space-x-3 hover:bg-black transition-all disabled:opacity-50 disabled:cursor-not-allowed group shadow-2xl shadow-gray-200"
                    >
                      {loading ? (
                        <>
                          <Loader2 className="animate-spin" size={24} />
                          <span>Preparing Payment...</span>
                        </>
                      ) : (
                        <>
                          <span>Proceed to Payment</span>
                          <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
                        </>
                      )}
                    </button>
                  </motion.div>
                ) : (
                  <motion.div
                    key="payment-step"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-8"
                  >
                    <div className="flex items-center justify-between mb-8">
                      <button 
                        onClick={() => setStep('amount')}
                        className="text-gray-400 hover:text-gray-900 font-black text-xs uppercase tracking-widest flex items-center space-x-2"
                      >
                        <ArrowRight size={16} className="rotate-180" />
                        <span>Back to Amount</span>
                      </button>
                      <div className="text-right">
                        <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Amount to Donate</p>
                        <p className="text-3xl font-black text-green-600">${amount}</p>
                      </div>
                    </div>

                    <h3 className="text-2xl font-black text-gray-900 mb-6 flex items-center space-x-3">
                      <CreditCard className="text-purple-600" />
                      <span>Payment Details</span>
                    </h3>

                    {clientSecret && (
                      <Elements stripe={stripePromise} options={{ clientSecret }}>
                        <PaymentForm 
                          amount={parseFloat(amount)} 
                          donorInfo={donorInfo} 
                          onSuccess={handleSuccess}
                        />
                      </Elements>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </div>

          {/* Impact Sidebar */}
          <div className="space-y-6">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-green-600 p-8 rounded-[40px] text-white shadow-2xl shadow-green-200 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <Heart size={120} fill="currentColor" />
              </div>
              <h4 className="text-2xl font-black mb-6 relative z-10">Your Impact</h4>
              <div className="space-y-6 relative z-10">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 size={24} />
                  </div>
                  <p className="text-sm font-bold leading-relaxed">
                    $10 provides 5 meals to families in need.
                  </p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 size={24} />
                  </div>
                  <p className="text-sm font-bold leading-relaxed">
                    $50 supports a local NGO for a week.
                  </p>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 size={24} />
                  </div>
                  <p className="text-sm font-bold leading-relaxed">
                    $100 helps us expand to a new city.
                  </p>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-white p-8 rounded-[40px] border border-gray-100 shadow-xl shadow-gray-100"
            >
              <h4 className="text-xl font-black text-gray-900 mb-6">Recent Donors</h4>
              <div className="space-y-6">
                {[
                  { name: 'Sarah J.', amount: 50, time: '2h ago' },
                  { name: 'Michael R.', amount: 100, time: '5h ago' },
                  { name: 'Anonymous', amount: 25, time: '1d ago' },
                ].map((donor, i) => (
                  <div key={i} className="flex items-center justify-between group cursor-default">
                    <div className="flex items-center space-x-4">
                      <div className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-xs font-black text-gray-600 group-hover:bg-green-50 group-hover:text-green-600 transition-colors">
                        {donor.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-black text-gray-900">{donor.name}</p>
                        <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{donor.time}</p>
                      </div>
                    </div>
                    <span className="text-sm font-black text-green-600">+${donor.amount}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Donate;
