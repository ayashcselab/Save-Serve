import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, ArrowRight, Heart, Share2, Download } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import { db } from '../firebase/firebase';
import { collection, query, where, getDocs, updateDoc, doc, serverTimestamp } from 'firebase/firestore';
import { toast } from 'sonner';
import confetti from 'canvas-confetti';

const DonationSuccess = () => {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');
  const paymentIntentId = searchParams.get('payment_intent');
  const [donationData, setDonationData] = useState<any>(null);
  const [isUpdating, setIsUpdating] = useState(true);

  useEffect(() => {
    const confirmDonation = async () => {
      if (!sessionId && !paymentIntentId) {
        setIsUpdating(false);
        return;
      }
      
      try {
        let q;
        if (sessionId) {
          q = query(collection(db, 'donations'), where('stripeSessionId', '==', sessionId));
        } else {
          q = query(collection(db, 'donations'), where('paymentIntentId', '==', paymentIntentId));
        }
        
        const querySnapshot = await getDocs(q);
        
        if (!querySnapshot.empty) {
          const donationDoc = querySnapshot.docs[0];
          const data = donationDoc.data() as any;
          setDonationData(data);

          if (data.status !== 'Completed') {
            await updateDoc(doc(db, 'donations', donationDoc.id), {
              status: 'Completed',
              updatedAt: serverTimestamp(),
            });
            
            // Trigger confetti on first completion
            confetti({
              particleCount: 150,
              spread: 70,
              origin: { y: 0.6 },
              colors: ['#16a34a', '#22c55e', '#4ade80', '#ffffff']
            });
            
            toast.success('Donation confirmed! Thank you.');
          }
        }
      } catch (error) {
        console.error('Error confirming donation:', error);
        toast.error('Could not verify donation status.');
      } finally {
        setIsUpdating(false);
      }
    };

    confirmDonation();
  }, [sessionId]);

  return (
    <div className="min-h-screen bg-[#f8fafc] flex items-center justify-center p-6 pt-24">
      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white p-8 md:p-12 rounded-[48px] shadow-[0_32px_64px_-16px_rgba(22,163,74,0.15)] border border-green-50 max-w-2xl w-full text-center relative overflow-hidden"
      >
        {/* Decorative background elements */}
        <div className="absolute top-0 left-0 w-full h-2 bg-green-500" />
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-green-50 rounded-full blur-3xl opacity-50" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-green-50 rounded-full blur-3xl opacity-50" />

        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 12, stiffness: 200, delay: 0.2 }}
          className="w-24 h-24 bg-green-100 text-green-600 rounded-[32px] flex items-center justify-center mx-auto mb-8 shadow-inner"
        >
          <CheckCircle2 size={48} strokeWidth={2.5} />
        </motion.div>

        <h1 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tight mb-4">
          Impact Confirmed!
        </h1>
        
        <p className="text-lg text-gray-600 font-bold mb-10 max-w-md mx-auto leading-relaxed">
          {donationData ? (
            <>Thank you, <span className="text-green-600">{donationData.donorName}</span>! Your contribution of <span className="text-gray-900">${donationData.amount}</span> is now fueling our mission to end hunger.</>
          ) : (
            "Your donation has been successfully processed. You're helping us make a real difference in the fight against hunger."
          )}
        </p>

        {donationData && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-gray-50 rounded-3xl p-6 mb-10 border border-gray-100 text-left"
          >
            <div className="flex justify-between items-center mb-4">
              <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Donation Details</span>
              <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-[10px] font-black uppercase tracking-widest">
                {donationData.status}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">Amount</p>
                <p className="text-xl font-black text-gray-900">${donationData.amount}</p>
              </div>
              <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">Date</p>
                <p className="text-sm font-black text-gray-900">
                  {donationData.createdAt?.toDate().toLocaleDateString() || new Date().toLocaleDateString()}
                </p>
              </div>
            </div>
          </motion.div>
        )}
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
          <Link 
            to="/" 
            className="flex-1 py-5 bg-gray-900 text-white rounded-2xl font-black flex items-center justify-center space-x-3 hover:bg-black transition-all group shadow-lg shadow-gray-200"
          >
            <span>Back to Home</span>
            <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />
          </Link>
          <button 
            onClick={() => toast.info('Receipt feature coming soon!')}
            className="flex-1 py-5 bg-white text-gray-900 border-2 border-gray-100 rounded-2xl font-black flex items-center justify-center space-x-3 hover:border-gray-200 transition-all"
          >
            <Download size={20} />
            <span>Get Receipt</span>
          </button>
        </div>

        <div className="flex flex-col items-center space-y-4">
          <div className="flex items-center space-x-2 text-red-500">
            <Heart size={16} fill="currentColor" />
            <span className="text-[10px] font-black uppercase tracking-widest">You're a Hero</span>
          </div>
          <button 
            onClick={() => {
              navigator.share?.({
                title: 'I just donated to SAVE & SERVE!',
                text: 'Help us fight hunger by donating to SAVE & SERVE.',
                url: window.location.origin
              }).catch(() => toast.error('Sharing not supported on this browser'));
            }}
            className="flex items-center space-x-2 text-gray-400 hover:text-gray-600 transition-colors"
          >
            <Share2 size={14} />
            <span className="text-[10px] font-black uppercase tracking-widest">Spread the Word</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default DonationSuccess;
