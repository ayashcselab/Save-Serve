import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, Package, Heart, ShieldCheck, Search, Filter, 
  Trash2, CheckCircle, XCircle, MoreVertical, 
  TrendingUp, TrendingDown, DollarSign, Activity,
  ArrowRight, Download, RefreshCw, Truck
} from 'lucide-react';
import { db } from '../firebase/firebase';
import { 
  collection, query, onSnapshot, doc, updateDoc, 
  deleteDoc, orderBy, limit, where, getDocs,
  Timestamp
} from 'firebase/firestore';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, LineChart, Line,
  PieChart, Pie, Cell
} from 'recharts';

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState<'users' | 'food' | 'donations' | 'analytics'>('analytics');
  const [users, setUsers] = useState<any[]>([]);
  const [foodItems, setFoodItems] = useState<any[]>([]);
  const [donations, setDonations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');

  useEffect(() => {
    setLoading(true);
    
    // Listen to Users
    const unsubUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      setUsers(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Listen to Food Items
    const unsubFood = onSnapshot(query(collection(db, 'foodItems'), orderBy('createdAt', 'desc')), (snapshot) => {
      setFoodItems(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    // Listen to Donations
    const unsubDonations = onSnapshot(query(collection(db, 'donations'), orderBy('createdAt', 'desc')), (snapshot) => {
      setDonations(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    setLoading(false);
    return () => {
      unsubUsers();
      unsubFood();
      unsubDonations();
    };
  }, []);

  const stats = useMemo(() => {
    const totalDonations = donations.reduce((acc, curr) => acc + (curr.amount || 0), 0);
    const activeUsers = users.length;
    const rescuedMeals = foodItems.filter(item => item.status === 'Collected' || item.status === 'Distributed').length;
    const pendingVerifications = users.filter(user => !user.isVerified).length;

    return { totalDonations, activeUsers, rescuedMeals, pendingVerifications };
  }, [users, foodItems, donations]);

  const handleVerifyUser = async (userId: string, status: boolean) => {
    try {
      await updateDoc(doc(db, 'users', userId), { isVerified: status });
      toast.success(`User ${status ? 'verified' : 'unverified'} successfully`);
    } catch (error) {
      toast.error('Failed to update user status');
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (!window.confirm('Are you sure you want to delete this user? This action is irreversible.')) return;
    try {
      await deleteDoc(doc(db, 'users', userId));
      toast.success('User deleted successfully');
    } catch (error) {
      toast.error('Failed to delete user');
    }
  };

  const handleDeleteFood = async (foodId: string) => {
    if (!window.confirm('Are you sure you want to delete this food item?')) return;
    try {
      await deleteDoc(doc(db, 'foodItems', foodId));
      toast.success('Food item deleted');
    } catch (error) {
      toast.error('Failed to delete food item');
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name?.toLowerCase().includes(searchTerm.toLowerCase()) || user.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || user.role === filterRole;
    return matchesSearch && matchesRole;
  });

  const filteredFood = foodItems.filter(item => 
    item.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    item.restaurantName?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
          <div>
            <h1 className="text-4xl font-black text-gray-900 tracking-tight mb-2">Admin Command Center</h1>
            <p className="text-gray-500 font-bold">Manage users, donations, and platform impact in real-time.</p>
          </div>
          <div className="flex items-center space-x-4">
            <button className="p-3 bg-white border border-gray-200 rounded-2xl text-gray-600 hover:bg-gray-50 transition-all">
              <Download size={20} />
            </button>
            <button className="p-3 bg-white border border-gray-200 rounded-2xl text-gray-600 hover:bg-gray-50 transition-all">
              <RefreshCw size={20} />
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {[
            { label: 'Total Donations', value: `$${stats.totalDonations.toLocaleString()}`, icon: <DollarSign />, color: 'bg-green-50 text-green-600' },
            { label: 'Active Users', value: stats.activeUsers, icon: <Users />, color: 'bg-blue-50 text-blue-600' },
            { label: 'Rescued Meals', value: stats.rescuedMeals, icon: <Package />, color: 'bg-orange-50 text-orange-600' },
            { label: 'Pending Verification', value: stats.pendingVerifications, icon: <ShieldCheck />, color: 'bg-purple-50 text-purple-600' }
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm"
            >
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-4 ${stat.color}`}>
                {stat.icon}
              </div>
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">{stat.label}</p>
              <h3 className="text-2xl font-black text-gray-900">{stat.value}</h3>
            </motion.div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex space-x-2 mb-8 bg-white p-2 rounded-2xl border border-gray-100 w-fit overflow-x-auto max-w-full">
          {[
            { id: 'analytics', label: 'Analytics', icon: <Activity /> },
            { id: 'users', label: 'Users', icon: <Users /> },
            { id: 'food', label: 'Food Items', icon: <Package /> },
            { id: 'pickups', label: 'NGO Pickups', icon: <Truck /> },
            { id: 'donations', label: 'Donations', icon: <Heart /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setSearchTerm('');
              }}
              className={`flex items-center space-x-2 px-6 py-3 rounded-xl font-black text-xs uppercase tracking-widest transition-all whitespace-nowrap ${
                activeTab === tab.id 
                  ? 'bg-gray-900 text-white shadow-lg' 
                  : 'text-gray-500 hover:bg-gray-50'
              }`}
            >
              {tab.icon}
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="bg-white rounded-[32px] border border-gray-100 shadow-xl shadow-gray-200/50 overflow-hidden">
          <AnimatePresence mode="wait">
            {activeTab === 'analytics' && (
              <motion.div
                key="analytics"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-8"
              >
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-gray-50 p-8 rounded-[32px]">
                    <h4 className="text-xl font-black text-gray-900 mb-8">Donation Growth</h4>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={donations.slice(0, 7).reverse()}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                          <XAxis dataKey="createdAt" tickFormatter={(val) => format(val?.toDate() || new Date(), 'MMM d')} />
                          <YAxis />
                          <Tooltip />
                          <Bar dataKey="amount" fill="#10b981" radius={[8, 8, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                  <div className="bg-gray-50 p-8 rounded-[32px]">
                    <h4 className="text-xl font-black text-gray-900 mb-8">User Distribution</h4>
                    <div className="h-[300px]">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              { name: 'Restaurants', value: users.filter(u => u.role === 'Restaurant').length },
                              { name: 'NGOs', value: users.filter(u => u.role === 'NGO').length },
                              { name: 'Admins', value: users.filter(u => u.role === 'Admin').length }
                            ]}
                            innerRadius={60}
                            outerRadius={100}
                            paddingAngle={5}
                            dataKey="value"
                          >
                            <Cell fill="#10b981" />
                            <Cell fill="#3b82f6" />
                            <Cell fill="#8b5cf6" />
                          </Pie>
                          <Tooltip />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'users' && (
              <motion.div
                key="users"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-8"
              >
                <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input
                      type="text"
                      placeholder="Search users..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl font-bold text-gray-900 focus:ring-2 focus:ring-gray-900 transition-all"
                    />
                  </div>
                  <div className="flex space-x-2 overflow-x-auto max-w-full pb-2">
                    {['all', 'Restaurant', 'NGO', 'Admin'].map((role) => (
                      <button
                        key={role}
                        onClick={() => setFilterRole(role)}
                        className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                          filterRole === role ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                        }`}
                      >
                        {role}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left border-b border-gray-100">
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">User</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">Role</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">Status</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {filteredUsers.map((user) => (
                        <tr key={user.id} className="group">
                          <td className="py-4">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-xs font-black text-gray-600">
                                {user.name?.charAt(0)}
                              </div>
                              <div>
                                <p className="text-sm font-black text-gray-900">{user.name}</p>
                                <p className="text-xs font-bold text-gray-400">{user.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-4">
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                              user.role === 'Restaurant' ? 'bg-green-50 text-green-600' : 
                              user.role === 'NGO' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'
                            }`}>
                              {user.role}
                            </span>
                          </td>
                          <td className="py-4">
                            <div className="flex items-center space-x-2">
                              <div className={`w-2 h-2 rounded-full ${user.isVerified ? 'bg-green-500' : 'bg-yellow-500'}`} />
                              <span className="text-xs font-bold text-gray-600">{user.isVerified ? 'Verified' : 'Pending'}</span>
                            </div>
                          </td>
                          <td className="py-4 text-right">
                            <div className="flex items-center justify-end space-x-2">
                              <button 
                                onClick={() => handleVerifyUser(user.id, !user.isVerified)}
                                className={`p-2 rounded-xl transition-all ${user.isVerified ? 'text-yellow-600 hover:bg-yellow-50' : 'text-green-600 hover:bg-green-50'}`}
                                title={user.isVerified ? 'Unverify' : 'Verify'}
                              >
                                {user.isVerified ? <XCircle size={18} /> : <CheckCircle size={18} />}
                              </button>
                              <button 
                                onClick={() => handleDeleteUser(user.id)}
                                className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition-all"
                                title="Delete"
                              >
                                <Trash2 size={18} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {activeTab === 'food' && (
              <motion.div
                key="food"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-8"
              >
                <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input
                      type="text"
                      placeholder="Search food items..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl font-bold text-gray-900 focus:ring-2 focus:ring-gray-900 transition-all"
                    />
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left border-b border-gray-100">
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">Food Item</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">Restaurant</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">Status</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {filteredFood.map((item) => (
                        <tr key={item.id} className="group">
                          <td className="py-4">
                            <div className="flex items-center space-x-3">
                              <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-orange-600">
                                <Package size={18} />
                              </div>
                              <div>
                                <p className="text-sm font-black text-gray-900">{item.name}</p>
                                <p className="text-xs font-bold text-gray-400">{item.quantity}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-4">
                            <p className="text-sm font-bold text-gray-600">{item.restaurantName}</p>
                          </td>
                          <td className="py-4">
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                              item.status === 'Available' ? 'bg-green-50 text-green-600' : 
                              item.status === 'Accepted' ? 'bg-blue-50 text-blue-600' : 'bg-gray-100 text-gray-500'
                            }`}>
                              {item.status}
                            </span>
                          </td>
                          <td className="py-4 text-right">
                            <button 
                              onClick={() => handleDeleteFood(item.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition-all"
                            >
                              <Trash2 size={18} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {activeTab === 'pickups' && (
              <motion.div
                key="pickups"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-8"
              >
                <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
                  <div className="relative w-full md:w-96">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                    <input
                      type="text"
                      placeholder="Search pickups..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-full pl-12 pr-4 py-3 bg-gray-50 border-none rounded-2xl font-bold text-gray-900 focus:ring-2 focus:ring-gray-900 transition-all"
                    />
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left border-b border-gray-100">
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">NGO</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">Food Item</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">Restaurant</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400">Status</th>
                        <th className="pb-4 text-[10px] font-black uppercase tracking-widest text-gray-400 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {foodItems.filter(item => item.ngoId && (
                        item.ngoName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                        item.name?.toLowerCase().includes(searchTerm.toLowerCase())
                      )).map((item) => (
                        <tr key={item.id} className="group">
                          <td className="py-4">
                            <p className="text-sm font-black text-gray-900">{item.ngoName || 'N/A'}</p>
                          </td>
                          <td className="py-4">
                            <p className="text-sm font-bold text-gray-600">{item.name}</p>
                          </td>
                          <td className="py-4">
                            <p className="text-sm font-bold text-gray-600">{item.restaurantName}</p>
                          </td>
                          <td className="py-4">
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                              item.status === 'Distributed' ? 'bg-green-50 text-green-600' : 
                              item.status === 'Collected' ? 'bg-blue-50 text-blue-600' : 'bg-yellow-50 text-yellow-600'
                            }`}>
                              {item.status}
                            </span>
                          </td>
                          <td className="py-4 text-right">
                            <button 
                              onClick={() => handleDeleteFood(item.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-xl transition-all"
                            >
                              <Trash2 size={18} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {activeTab === 'donations' && (
              <motion.div
                key="donations"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-8"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {donations.map((donation) => (
                    <div key={donation.id} className="bg-gray-50 p-6 rounded-[32px] border border-gray-100 group hover:bg-white hover:shadow-xl transition-all">
                      <div className="flex justify-between items-start mb-6">
                        <div className="w-12 h-12 bg-green-100 text-green-600 rounded-2xl flex items-center justify-center">
                          <DollarSign size={24} />
                        </div>
                        <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                          donation.status === 'Completed' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'
                        }`}>
                          {donation.status}
                        </span>
                      </div>
                      <h4 className="text-2xl font-black text-gray-900 mb-1">${donation.amount}</h4>
                      <p className="text-xs font-bold text-gray-400 mb-6">from {donation.donorName}</p>
                      <div className="flex items-center justify-between pt-6 border-t border-gray-200/50">
                        <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                          {donation.createdAt ? format(donation.createdAt.toDate(), 'MMM d, yyyy') : 'Recently'}
                        </span>
                        <button className="text-gray-400 hover:text-gray-900 transition-colors">
                          <ArrowRight size={18} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
