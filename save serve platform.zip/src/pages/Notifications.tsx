import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy, updateDoc, doc } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { useAuth } from '../context/AuthContext';
import { Card, Button } from '../components/UI';
import { Bell, CheckCircle2, Utensils, HandHeart, Clock, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Notifications: React.FC = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'notifications'),
      where('userId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      // Client-side sort
      items.sort((a: any, b: any) => {
        const timeA = a.createdAt?.toMillis() || 0;
        const timeB = b.createdAt?.toMillis() || 0;
        return timeB - timeA;
      });
      setNotifications(items);
      setLoading(false);
    }, (error) => {
      console.error("Firestore Error in Notifications:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const markAsRead = async (id: string) => {
    await updateDoc(doc(db, 'notifications', id), { read: true });
  };

  const markAllAsRead = async () => {
    const unread = notifications.filter(n => !n.read);
    const promises = unread.map(n => updateDoc(doc(db, 'notifications', n.id), { read: true }));
    await Promise.all(promises);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'new_food': return <Utensils className="text-emerald-600" size={20} />;
      case 'pickup_accepted': return <HandHeart className="text-blue-600" size={20} />;
      default: return <Bell className="text-slate-600" size={20} />;
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Notifications</h1>
          <p className="text-slate-500">Stay updated with real-time alerts from the network.</p>
        </div>
        {notifications.some(n => !n.read) && (
          <Button variant="ghost" onClick={markAllAsRead} className="text-emerald-600 font-bold">
            Mark all as read
          </Button>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="animate-spin text-emerald-600" size={40} />
        </div>
      ) : notifications.length > 0 ? (
        <div className="space-y-4">
          <AnimatePresence>
            {notifications.map((n) => (
              <motion.div
                key={n.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <Card 
                  className={`p-5 transition-all cursor-pointer border-l-4 ${
                    n.read ? 'border-transparent bg-white' : 'border-emerald-500 bg-emerald-50/30'
                  }`}
                  onClick={() => !n.read && markAsRead(n.id)}
                >
                  <div className="flex gap-4">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      n.read ? 'bg-slate-100' : 'bg-emerald-100'
                    }`}>
                      {getIcon(n.type)}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <p className={`text-sm ${n.read ? 'text-slate-600' : 'text-slate-900 font-bold'}`}>
                          {n.message}
                        </p>
                        {!n.read && <div className="w-2 h-2 bg-emerald-500 rounded-full flex-shrink-0" />}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <Clock size={12} />
                        {new Date(n.createdAt?.toDate()).toLocaleString()}
                      </div>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      ) : (
        <div className="text-center py-20 bg-white rounded-3xl border border-slate-100">
          <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
            <Bell size={40} className="text-slate-300" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">No notifications yet</h3>
          <p className="text-slate-500">We'll alert you when something important happens.</p>
        </div>
      )}
    </div>
  );
};
