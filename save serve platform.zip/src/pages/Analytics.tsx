import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { useAuth } from '../context/AuthContext';
import { Card, Badge } from '../components/UI';
import { 
  BarChart2, 
  TrendingUp, 
  TrendingDown, 
  PieChart, 
  Calendar,
  Utensils,
  HandHeart,
  Globe
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Cell,
  PieChart as RePieChart,
  Pie
} from 'recharts';

export const Analytics: React.FC = () => {
  const { user, isRestaurant } = useAuth();
  const [data, setData] = useState<any[]>([]);
  const [summary, setSummary] = useState({
    total: 0,
    growth: 15,
    efficiency: 92
  });

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'analytics'),
      isRestaurant ? where('restaurantId', '==', user.uid) : where('ngoId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const analytics = snapshot.docs.map(doc => ({
        date: new Date(doc.data().timestamp?.toDate()).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        value: isRestaurant ? doc.data().totalDonated : doc.data().totalCollected,
        timestamp: doc.data().timestamp?.toMillis() || 0
      }));
      
      // Client-side sort
      analytics.sort((a, b) => a.timestamp - b.timestamp);

      setData(analytics);
      setSummary(prev => ({
        ...prev,
        total: analytics.reduce((acc, curr) => acc + curr.value, 0)
      }));
    }, (error) => {
      console.error("Firestore Error in Analytics:", error);
    });

    return () => unsubscribe();
  }, [user, isRestaurant]);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Impact Analytics</h1>
          <p className="text-slate-500">Track your contribution to the food rescue movement.</p>
        </div>
        <div className="flex items-center gap-3 bg-white p-1 rounded-2xl border border-slate-200 shadow-sm">
          {['Day', 'Week', 'Month', 'Year'].map((period) => (
            <button 
              key={period}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                period === 'Week' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-100' : 'text-slate-500 hover:bg-slate-50'
              }`}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
        <Card className="p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full -mr-16 -mt-16" />
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
              {isRestaurant ? <Utensils size={24} /> : <HandHeart size={24} />}
            </div>
            <h3 className="text-slate-500 font-bold uppercase tracking-wider text-xs">Total Impact</h3>
          </div>
          <p className="text-4xl font-black text-slate-900">{summary.total}</p>
          <div className="flex items-center gap-2 mt-4 text-emerald-600 font-bold text-sm">
            <TrendingUp size={16} />
            <span>+{summary.growth}% from last period</span>
          </div>
        </Card>

        <Card className="p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-50 rounded-full -mr-16 -mt-16" />
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center">
              <Globe size={24} />
            </div>
            <h3 className="text-slate-500 font-bold uppercase tracking-wider text-xs">Network Reach</h3>
          </div>
          <p className="text-4xl font-black text-slate-900">12</p>
          <div className="flex items-center gap-2 mt-4 text-blue-600 font-bold text-sm">
            <TrendingUp size={16} />
            <span>Active partners connected</span>
          </div>
        </Card>

        <Card className="p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-50 rounded-full -mr-16 -mt-16" />
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center">
              <PieChart size={24} />
            </div>
            <h3 className="text-slate-500 font-bold uppercase tracking-wider text-xs">Efficiency Rate</h3>
          </div>
          <p className="text-4xl font-black text-slate-900">{summary.efficiency}%</p>
          <div className="flex items-center gap-2 mt-4 text-amber-600 font-bold text-sm">
            <TrendingDown size={16} className="rotate-180" />
            <span>Top 5% in the region</span>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card className="p-8">
          <h3 className="text-xl font-bold text-slate-900 mb-8">Performance Trend</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)'}}
                />
                <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={4} dot={{r: 6, fill: '#10b981', strokeWidth: 3, stroke: '#fff'}} activeDot={{r: 8}} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-8">
          <h3 className="text-xl font-bold text-slate-900 mb-8">Distribution by Category</h3>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={[
                { name: 'Cooked', value: 45 },
                { name: 'Raw', value: 25 },
                { name: 'Bakery', value: 20 },
                { name: 'Other', value: 10 },
              ]}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                  {[0, 1, 2, 3].map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
};
