import React from 'react';
import { Link, Navigate } from 'react-router-dom';
import { 
  Heart, 
  ShieldCheck, 
  Zap, 
  ArrowRight, 
  Utensils, 
  HandHeart, 
  Users,
  CheckCircle2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/UI';
import { motion } from 'motion/react';

const LandingPage: React.FC = () => {
  const { user, loading } = useAuth();

  if (loading) return null;
  if (user) return <Navigate to="/dashboard" />;

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full -z-10 opacity-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-emerald-400 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-400 rounded-full blur-3xl" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100 text-emerald-700 text-sm font-bold mb-8">
              <Heart size={16} />
              Join the movement to end food waste
            </span>
            <h1 className="text-5xl md:text-7xl font-black text-slate-900 mb-6 tracking-tight">
              Save Food, <br />
              <span className="text-emerald-600">Serve Humanity.</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto mb-10 leading-relaxed">
              The real-time platform connecting restaurants with surplus food to NGOs in need. 
              Together, we can ensure no meal goes to waste.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/signup">
                <Button className="px-8 py-4 text-lg rounded-2xl flex items-center gap-2">
                  Get Started Now <ArrowRight size={20} />
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="outline" className="px-8 py-4 text-lg rounded-2xl">
                  Partner Login
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-white border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div>
              <div className="text-4xl font-black text-slate-900 mb-2">10k+</div>
              <div className="text-slate-500 font-medium">Meals Rescued</div>
            </div>
            <div>
              <div className="text-4xl font-black text-slate-900 mb-2">500+</div>
              <div className="text-slate-500 font-medium">Partner Restaurants</div>
            </div>
            <div>
              <div className="text-4xl font-black text-slate-900 mb-2">200+</div>
              <div className="text-slate-500 font-medium">Active NGOs</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">How It Works</h2>
            <p className="text-slate-600 max-w-xl mx-auto">Our streamlined process ensures food reaches those in need quickly and safely.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                title: "Restaurants Donate",
                desc: "Upload surplus food details and photos in seconds. Set your preferred pickup time.",
                icon: Utensils,
                color: "bg-orange-100 text-orange-600"
              },
              {
                title: "NGOs Accept",
                desc: "Browse real-time listings and accept pickups that match your distribution capacity.",
                icon: HandHeart,
                color: "bg-emerald-100 text-emerald-600"
              },
              {
                title: "Real-time Tracking",
                desc: "Monitor every step from pickup to distribution with live notifications and analytics.",
                icon: Zap,
                color: "bg-blue-100 text-blue-600"
              }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                whileHover={{ y: -10 }}
                className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm"
              >
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 ${feature.color}`}>
                  <feature.icon size={28} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 rounded-[3rem] p-12 md:p-20 text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl" />
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-8">Ready to make a difference?</h2>
            <div className="flex flex-wrap justify-center gap-6">
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 size={20} className="text-emerald-500" />
                <span>Free for NGOs</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 size={20} className="text-emerald-500" />
                <span>Real-time Alerts</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <CheckCircle2 size={20} className="text-emerald-500" />
                <span>Impact Analytics</span>
              </div>
            </div>
            <Link to="/signup" className="inline-block mt-12">
              <Button className="px-10 py-4 text-lg rounded-2xl bg-white text-slate-900 hover:bg-slate-100">
                Join Save & Serve Today
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">S</div>
            <span className="text-lg font-bold text-slate-900">SAVE & SERVE</span>
          </div>
          <p className="text-slate-500 text-sm">© 2026 Save & Serve. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
