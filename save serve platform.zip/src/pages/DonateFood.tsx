import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { foodService } from '../services/foodService';
import { Button, Input, Card } from '../components/UI';
import { Utensils, MapPin, Clock, Package, Image as ImageIcon, ArrowLeft, Loader2, Map as MapIcon } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, useMapEvents } from 'react-leaflet';
import L from 'leaflet';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

function LocationMarker({ position, setPosition, formData, profile }: { 
  position: [number, number], 
  setPosition: (pos: [number, number]) => void,
  formData: any,
  profile: any
}) {
  useMapEvents({
    click(e) {
      setPosition([e.latlng.lat, e.latlng.lng]);
    },
  });

  return position ? (
    <Marker position={position}>
      <Popup>
        <div className="p-3 min-w-[200px]">
          <div className="flex items-center space-x-2 mb-2">
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center text-green-600">
              <Utensils size={16} />
            </div>
            <h4 className="font-black text-gray-900 leading-tight">{formData.name || 'New Donation'}</h4>
          </div>
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">{profile?.name || 'Your Restaurant'}</p>
          <div className="flex justify-between items-center pt-2 border-t border-gray-100">
            <span className="text-xs font-black text-green-600">{formData.quantity || 'Quantity info'}</span>
            <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Selected Location</span>
          </div>
        </div>
      </Popup>
    </Marker>
  ) : null;
}

export const DonateFood: React.FC = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [image, setImage] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [position, setPosition] = useState<[number, number]>([23.8103, 90.4125]); // Default to Dhaka
  
  const [formData, setFormData] = useState({
    name: '',
    quantity: '',
    pickupTime: '',
    location: profile?.location || '',
  });

  useEffect(() => {
    if (profile?.lat && profile?.lng) {
      setPosition([profile.lat, profile.lng]);
    }
  }, [profile]);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImage(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !profile) return;
    
    setLoading(true);
    try {
      await foodService.uploadFood({
        restaurantId: user.uid,
        restaurantName: profile.name,
        name: formData.name,
        quantity: formData.quantity,
        pickupTime: formData.pickupTime,
        location: formData.location,
        status: 'Available',
        imageURL: '',
        lat: position[0],
        lng: position[1],
      } as any, image || undefined);
      
      navigate('/dashboard');
    } catch (error) {
      console.error('Error donating food:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-slate-500 hover:text-slate-900 mb-6 transition-colors">
        <ArrowLeft size={20} />
        Back to Dashboard
      </button>

      <div className="mb-8">
        <h1 className="text-4xl font-black text-slate-900 tracking-tight">Donate Surplus Food</h1>
        <p className="text-slate-500 text-lg">Fill in the details below to share your surplus food with local NGOs.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="p-8 border-none shadow-2xl shadow-slate-200/50 rounded-[40px]">
            <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-2">
              <Package className="text-emerald-500" />
              Food Details
            </h3>
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Food Item Name</label>
                <div className="relative">
                  <Utensils className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <Input
                    placeholder="e.g. Fresh Vegetable Biryani"
                    className="pl-12 py-4 bg-slate-50 border-none rounded-2xl font-bold"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Quantity / Servings</label>
                <div className="relative">
                  <Package className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <Input
                    placeholder="e.g. 20 Servings / 5 KG"
                    className="pl-12 py-4 bg-slate-50 border-none rounded-2xl font-bold"
                    value={formData.quantity}
                    onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Pickup Time Window</label>
                <div className="relative">
                  <Clock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <Input
                    placeholder="e.g. Today, 6 PM - 9 PM"
                    className="pl-12 py-4 bg-slate-50 border-none rounded-2xl font-bold"
                    value={formData.pickupTime}
                    onChange={(e) => setFormData({...formData, pickupTime: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Pickup Location (Address)</label>
                <div className="relative">
                  <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <Input
                    placeholder="Full Address"
                    className="pl-12 py-4 bg-slate-50 border-none rounded-2xl font-bold"
                    value={formData.location}
                    onChange={(e) => setFormData({...formData, location: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div className="pt-4">
                <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Food Image</label>
                <div 
                  className={`aspect-video border-2 border-dashed rounded-3xl flex flex-col items-center justify-center p-6 transition-all cursor-pointer overflow-hidden relative ${
                    preview ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 hover:border-emerald-400 hover:bg-slate-50'
                  }`}
                  onClick={() => document.getElementById('food-image')?.click()}
                >
                  {preview ? (
                    <img src={preview} alt="Preview" className="w-full h-full object-cover absolute inset-0" />
                  ) : (
                    <>
                      <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 mb-4">
                        <ImageIcon size={32} />
                      </div>
                      <p className="text-sm font-black text-slate-900">Click to upload image</p>
                      <p className="text-xs text-slate-500 mt-1">PNG, JPG up to 5MB</p>
                    </>
                  )}
                  <input 
                    id="food-image"
                    type="file" 
                    className="hidden" 
                    accept="image/*"
                    onChange={handleImageChange}
                  />
                </div>
              </div>
            </div>
          </Card>

          <div className="space-y-8">
            <Card className="p-8 border-none shadow-2xl shadow-slate-200/50 rounded-[40px] overflow-hidden">
              <h3 className="text-xl font-black text-slate-900 mb-6 flex items-center gap-2">
                <MapIcon className="text-emerald-500" />
                Set Map Location
              </h3>
              <p className="text-sm text-slate-500 mb-4 font-medium">Click on the map to set the exact pickup location for NGOs.</p>
              <div className="h-[400px] rounded-3xl overflow-hidden border-4 border-slate-50 relative z-10">
                <MapContainer 
                  center={position} 
                  zoom={13} 
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <LocationMarker 
                    position={position} 
                    setPosition={setPosition} 
                    formData={formData}
                    profile={profile}
                  />
                </MapContainer>
              </div>
              <div className="mt-4 flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-widest">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                Lat: {position[0].toFixed(4)}, Lng: {position[1].toFixed(4)}
              </div>
            </Card>

            <div className="flex flex-col gap-4">
              <Button 
                className="w-full py-6 rounded-[24px] text-xl font-black flex items-center justify-center gap-3 bg-emerald-600 hover:bg-emerald-700 shadow-xl shadow-emerald-200" 
                disabled={loading}
              >
                {loading ? <Loader2 className="animate-spin" size={24} /> : <Utensils size={24} />}
                {loading ? 'POSTING DONATION...' : 'POST DONATION'}
              </Button>
              <Button 
                variant="outline" 
                type="button" 
                onClick={() => navigate(-1)}
                className="w-full py-4 rounded-[24px] font-black text-slate-400 border-slate-100"
              >
                CANCEL
              </Button>
            </div>
          </div>
        </div>
      </form>

      <style dangerouslySetInnerHTML={{ __html: `
        .leaflet-container {
          z-index: 1;
        }
      `}} />
    </div>
  );
};
