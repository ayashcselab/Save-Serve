import React, { useState, useRef, useEffect } from 'react';
import { X, Loader2, Plus, Image as ImageIcon, Upload, MapPin, Map as MapIcon } from 'lucide-react';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase/firebase';
import { handleFirestoreError, OperationType } from '../firebase/errorHandler';
import { useAuth } from '../context/AuthContext';
import { toast } from 'sonner';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

function LocationMarker({ position, setPosition }: { position: [number, number], setPosition: (pos: [number, number]) => void }) {
  useMapEvents({
    click(e) {
      setPosition([e.latlng.lat, e.latlng.lng]);
    },
  });

  return position ? (
    <Marker position={position} />
  ) : null;
}

interface AddFoodModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddFoodModal: React.FC<AddFoodModalProps> = ({ isOpen, onClose }) => {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string>('');
  const [useUrl, setUseUrl] = useState(true);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [position, setPosition] = useState<[number, number]>([23.8103, 90.4125]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    quantity: '',
    pickupTime: '',
    location: profile?.location || '',
    category: '',
    customCategory: '',
    priority: 'Normal' as 'Normal' | 'Urgent',
  });

  useEffect(() => {
    if (profile?.lat && profile?.lng) {
      setPosition([profile.lat, profile.lng]);
    }
  }, [profile]);

  const categories = [
    'Cooked Meal',
    'Raw Ingredients',
    'Bakery & Sweets',
    'Fruits & Vegetables',
    'Beverages',
    'Other'
  ];

  const suggestions: Record<string, string[]> = {
    'Cooked Meal': ['Rice & Curry', 'Pasta', 'Biryani', 'Sandwiches', 'Soup'],
    'Raw Ingredients': ['Rice Bags', 'Flour', 'Lentils', 'Canned Goods'],
    'Bakery & Sweets': ['Bread', 'Cakes', 'Pastries', 'Cookies'],
    'Fruits & Vegetables': ['Mixed Vegetables', 'Apples', 'Bananas', 'Potatoes'],
    'Beverages': ['Water Bottles', 'Juice Packs', 'Milk'],
  };

  if (!isOpen) return null;

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Image size must be less than 5MB');
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const compressImage = (file: File): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 1200;
          const MAX_HEIGHT = 1200;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          canvas.toBlob(
            (blob) => {
              if (blob) resolve(blob);
              else reject(new Error('Canvas to Blob failed'));
            },
            'image/jpeg',
            0.7
          );
        };
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const uploadImage = async (file: File): Promise<string> => {
    try {
      const compressedBlob = await compressImage(file);
      return new Promise((resolve, reject) => {
        const storageRef = ref(storage, `food-images/${Date.now()}_${file.name}`);
        const uploadTask = uploadBytesResumable(storageRef, compressedBlob);

        uploadTask.on(
          'state_changed',
          (snapshot) => {
            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
            setUploadProgress(progress);
          },
          (error) => {
            console.error("Upload error:", error);
            toast.error(`Upload failed: ${error.message}`);
            reject(error);
          },
          async () => {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            resolve(downloadURL);
          }
        );
      });
    } catch (error: any) {
      toast.error(`Image processing failed: ${error.message}`);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;

    const pickupDate = new Date(formData.pickupTime);
    if (pickupDate <= new Date()) {
      toast.error('Pickup time must be in the future');
      return;
    }

    setLoading(true);
    try {
      let finalImageUrl = imageUrl;
      
      if (!useUrl && imageFile) {
        finalImageUrl = await uploadImage(imageFile);
      }

      if (!finalImageUrl) {
        toast.error('Please provide an image URL or upload an image');
        setLoading(false);
        return;
      }

      await addDoc(collection(db, 'foodItems'), {
        restaurantId: profile.uid,
        restaurantName: profile.name,
        name: formData.name,
        category: formData.category === 'Other' ? formData.customCategory : formData.category,
        quantity: formData.quantity,
        imageUrl: finalImageUrl,
        pickupTime: pickupDate,
        location: formData.location,
        lat: position[0],
        lng: position[1],
        status: 'Available',
        priority: formData.priority,
        isDeleted: false,
        createdBy: profile.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        statusHistory: [{
          status: 'Available',
          timestamp: new Date(),
          updatedBy: profile.uid,
          notes: 'Food donation posted'
        }]
      });
      
      toast.success('Food donation posted successfully!');
      onClose();
      setFormData({ name: '', quantity: '', pickupTime: '', location: profile.location, category: '', customCategory: '', priority: 'Normal' });
      setImageFile(null);
      setImagePreview(null);
      setImageUrl('');
      setUploadProgress(0);
    } catch (error: any) {
      handleFirestoreError(error, OperationType.CREATE, 'foodItems');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-[40px] w-full max-w-4xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-200 max-h-[90vh] flex flex-col">
        <div className="px-8 py-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50 flex-shrink-0">
          <h2 className="text-2xl font-black text-gray-900 flex items-center space-x-3 uppercase tracking-tight">
            <Plus className="text-green-600" size={28} />
            <span>Post Surplus Food</span>
          </h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 transition-colors bg-white p-2 rounded-xl shadow-sm">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-8 overflow-y-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Column: Form Details */}
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Category</label>
                  <select
                    required
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none font-bold text-gray-900 focus:ring-2 focus:ring-green-500 transition-all"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value, name: '' })}
                  >
                    <option value="">Select a category</option>
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                {formData.category === 'Other' && (
                  <div className="col-span-2">
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Custom Category</label>
                    <input
                      required
                      type="text"
                      className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none font-bold text-gray-900 focus:ring-2 focus:ring-green-500 transition-all"
                      value={formData.customCategory}
                      onChange={(e) => setFormData({ ...formData, customCategory: e.target.value })}
                    />
                  </div>
                )}

                <div className="col-span-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Food Name / Item</label>
                  <input
                    required
                    type="text"
                    placeholder="e.g., 10 Lunch Boxes, Surplus Pasta"
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none font-bold text-gray-900 focus:ring-2 focus:ring-green-500 transition-all"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                  {formData.category && suggestions[formData.category] && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {suggestions[formData.category].map(suggestion => (
                        <button
                          key={suggestion}
                          type="button"
                          onClick={() => setFormData({ ...formData, name: suggestion })}
                          className="text-[10px] font-black uppercase tracking-widest bg-gray-100 hover:bg-gray-200 text-gray-500 px-3 py-1.5 rounded-lg transition-colors"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Quantity</label>
                  <input
                    required
                    type="text"
                    placeholder="e.g., 5kg, 20 servings"
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none font-bold text-gray-900 focus:ring-2 focus:ring-green-500 transition-all"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Priority</label>
                  <div className="flex bg-gray-100 p-1 rounded-xl">
                    <button 
                      type="button"
                      onClick={() => setFormData({ ...formData, priority: 'Normal' })}
                      className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${formData.priority === 'Normal' ? 'bg-white text-green-600 shadow-sm' : 'text-gray-400'}`}
                    >
                      Normal
                    </button>
                    <button 
                      type="button"
                      onClick={() => setFormData({ ...formData, priority: 'Urgent' })}
                      className={`flex-1 py-2 rounded-lg text-[10px] font-black uppercase tracking-wider transition-all ${formData.priority === 'Urgent' ? 'bg-white text-red-600 shadow-sm' : 'text-gray-400'}`}
                    >
                      Urgent
                    </button>
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Pickup Time</label>
                  <input
                    required
                    type="datetime-local"
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none font-bold text-gray-900 focus:ring-2 focus:ring-green-500 transition-all"
                    value={formData.pickupTime}
                    onChange={(e) => setFormData({ ...formData, pickupTime: e.target.value })}
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Pickup Location (Address)</label>
                  <textarea
                    required
                    placeholder="Full address for pickup"
                    className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none font-bold text-gray-900 focus:ring-2 focus:ring-green-500 transition-all resize-none h-24"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>
              </div>
            </div>

            {/* Right Column: Image & Map */}
            <div className="space-y-6">
              {/* Image Section */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Food Image</label>
                  <div className="flex bg-gray-100 p-1 rounded-lg text-[10px] font-black uppercase tracking-widest">
                    <button 
                      type="button"
                      onClick={() => setUseUrl(true)}
                      className={`px-3 py-1 rounded-md transition-all ${useUrl ? 'bg-white text-green-600 shadow-sm' : 'text-gray-400'}`}
                    >
                      URL
                    </button>
                    <button 
                      type="button"
                      onClick={() => setUseUrl(false)}
                      className={`px-3 py-1 rounded-md transition-all ${!useUrl ? 'bg-white text-green-600 shadow-sm' : 'text-gray-400'}`}
                    >
                      Upload
                    </button>
                  </div>
                </div>

                {useUrl ? (
                  <div className="space-y-2">
                    <input
                      type="url"
                      placeholder="Paste image URL here..."
                      className="w-full px-4 py-3 rounded-2xl bg-gray-50 border-none font-bold text-gray-900 focus:ring-2 focus:ring-green-500 transition-all text-sm"
                      value={imageUrl}
                      onChange={(e) => setImageUrl(e.target.value)}
                    />
                    {imageUrl && (
                      <div className="relative rounded-3xl overflow-hidden aspect-video bg-gray-50 border border-gray-100 shadow-inner">
                        <img 
                          src={imageUrl} 
                          alt="Preview" 
                          className="w-full h-full object-cover"
                          onError={() => toast.error('Invalid image URL')}
                        />
                      </div>
                    )}
                  </div>
                ) : (
                  <div 
                    onClick={() => fileInputRef.current?.click()}
                    className="relative group cursor-pointer border-2 border-dashed border-gray-200 rounded-3xl overflow-hidden aspect-video flex flex-col items-center justify-center bg-gray-50 hover:bg-gray-100 transition-all"
                  >
                    {imagePreview ? (
                      <>
                        <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <Upload className="text-white" size={32} />
                        </div>
                      </>
                    ) : (
                      <div className="flex flex-col items-center text-gray-400">
                        <ImageIcon size={40} strokeWidth={1.5} />
                        <span className="text-xs font-black uppercase tracking-widest mt-2">Click to upload image</span>
                      </div>
                    )}
                    {loading && uploadProgress > 0 && uploadProgress < 100 && (
                      <div className="absolute bottom-0 left-0 h-1.5 bg-green-500 transition-all" style={{ width: `${uploadProgress}%` }} />
                    )}
                  </div>
                )}
                <input type="file" ref={fileInputRef} onChange={handleImageChange} accept="image/*" className="hidden" />
              </div>

              {/* Map Section */}
              <div className="space-y-2">
                <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest">Set Map Location</label>
                <div className="h-[250px] rounded-3xl overflow-hidden border-4 border-gray-50 relative z-10 shadow-inner">
                  <MapContainer 
                    center={position} 
                    zoom={13} 
                    style={{ height: '100%', width: '100%' }}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    <LocationMarker position={position} setPosition={setPosition} />
                  </MapContainer>
                </div>
                <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                  <MapPin size={12} className="text-green-500" />
                  Lat: {position[0].toFixed(4)}, Lng: {position[1].toFixed(4)}
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-4 pt-4 flex-shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-4 rounded-2xl font-black text-xs uppercase tracking-widest text-gray-400 bg-gray-100 hover:bg-gray-200 transition-all"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-[2] bg-green-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-green-700 shadow-xl shadow-green-200 transition-all flex items-center justify-center space-x-2 disabled:opacity-70"
            >
              {loading ? (
                <>
                  <Loader2 className="animate-spin" size={20} />
                  <span>{uploadProgress > 0 && uploadProgress < 100 ? `Uploading... ${Math.round(uploadProgress)}%` : 'Posting...'}</span>
                </>
              ) : (
                <>
                  <Plus size={20} />
                  <span>Post Donation</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
      <style dangerouslySetInnerHTML={{ __html: `
        .leaflet-container {
          z-index: 1;
        }
      `}} />
    </div>
  );
};

export default AddFoodModal;
