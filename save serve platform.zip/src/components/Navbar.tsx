import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LogOut, Menu, X, Utensils, User } from 'lucide-react';
import { motion } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { auth } from '../firebase/firebase';
import { signOut } from 'firebase/auth';
import { toast } from 'sonner';
import NotificationCenter from './NotificationCenter';

const Navbar = () => {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = React.useState(false);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      toast.success('Logged out successfully');
      navigate('/');
    } catch (error) {
      toast.error('Failed to logout');
    }
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' },
    ...(profile?.role === 'Restaurant' ? [{ name: 'Dashboard', path: '/restaurant-dashboard' }] : []),
    ...(profile?.role === 'NGO' ? [{ name: 'Dashboard', path: '/ngo-dashboard' }] : []),
    ...(profile?.role === 'Admin' ? [{ name: 'Admin', path: '/admin' }] : []),
  ];

  return (
    <nav className="bg-white border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <motion.div
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <Link to="/" className="flex items-center space-x-2 group">
                <div className="relative">
                  <img 
                    src="https://yt3.googleusercontent.com/e7boBffUztPCJLtN6XadMCuIuule1lj7eO7zR5AKitQLs62SBnyYsuf3-qiJqNIp6X07SWAv=s900-c-k-c0x00ffffff-no-rj" 
                    alt="Save & Serve Logo" 
                    className="h-10 w-10 rounded-full border-2 border-transparent group-hover:border-green-500 transition-all duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 rounded-full bg-green-500/20 scale-0 group-hover:scale-110 transition-transform duration-300 -z-10" />
                </div>
                <span className="text-xl font-black text-gray-900 group-hover:text-green-600 transition-colors hidden sm:block tracking-tighter">
                  SAVE <span className="text-green-600">&</span> SERVE
                </span>
              </Link>
            </motion.div>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <motion.div
                key={link.path}
                whileHover={{ y: -2 }}
                whileTap={{ y: 0 }}
              >
                <Link 
                  to={link.path} 
                  className="text-sm font-black uppercase tracking-widest text-gray-500 hover:text-green-600 transition-colors relative group"
                >
                  {link.name}
                  <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-green-500 transition-all duration-300 group-hover:w-full" />
                </Link>
              </motion.div>
            ))}
            
            {user ? (
              <div className="flex items-center space-x-6">
                <NotificationCenter />
                <Link to="/profile" className="flex items-center space-x-3 group">
                  <div className="flex flex-col items-end">
                    <span className="text-sm font-bold text-gray-900 leading-none group-hover:text-green-600 transition-colors">
                      {profile?.name}
                    </span>
                    <span className="text-[10px] text-gray-500 font-medium uppercase tracking-wider mt-1">
                      {profile?.role}
                    </span>
                  </div>
                  <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center border border-green-100 overflow-hidden group-hover:border-green-500 transition-all">
                    {profile?.photoURL ? (
                      <img 
                        src={profile.photoURL} 
                        alt={profile.name} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <User className="text-green-600" size={20} />
                    )}
                  </div>
                </Link>
                <button
                  onClick={handleLogout}
                  className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                  title="Logout"
                >
                  <LogOut size={20} />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <Link to="/login" className="text-gray-600 hover:text-green-600 font-medium">Login</Link>
                <Link 
                  to="/signup" 
                  className="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 transition-colors"
                >
                  Sign Up
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center space-x-4">
            {user && <NotificationCenter />}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-600 hover:text-green-600"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 pt-2 pb-6 space-y-2">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              onClick={() => setIsOpen(false)}
              className="block px-3 py-2 text-gray-600 hover:text-green-600 font-medium"
            >
              {link.name}
            </Link>
          ))}
          {user ? (
            <div className="pt-4 border-t border-gray-100">
              <Link 
                to="/profile" 
                onClick={() => setIsOpen(false)}
                className="px-3 py-2 flex items-center space-x-3 mb-4 hover:bg-gray-50 rounded-xl transition-all"
              >
                <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center border border-green-100 overflow-hidden">
                  {profile?.photoURL ? (
                    <img 
                      src={profile.photoURL} 
                      alt={profile.name} 
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <User className="text-green-600" size={20} />
                  )}
                </div>
                <div className="flex flex-col">
                  <span className="text-sm font-bold text-gray-900 leading-none">
                    {profile?.name}
                  </span>
                  <span className="text-[10px] text-gray-500 font-medium uppercase tracking-wider mt-1">
                    {profile?.role}
                  </span>
                </div>
              </Link>
              <button
                onClick={() => {
                  handleLogout();
                  setIsOpen(false);
                }}
                className="flex items-center space-x-2 px-3 py-2 text-red-600 font-medium w-full text-left"
              >
                <LogOut size={18} />
                <span>Logout</span>
              </button>
            </div>
          ) : (
            <div className="pt-4 border-t border-gray-100 flex flex-col space-y-2">
              <Link
                to="/login"
                onClick={() => setIsOpen(false)}
                className="px-3 py-2 text-gray-600 font-medium"
              >
                Login
              </Link>
              <Link
                to="/signup"
                onClick={() => setIsOpen(false)}
                className="px-3 py-2 bg-green-600 text-white rounded-lg font-medium text-center"
              >
                Sign Up
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
