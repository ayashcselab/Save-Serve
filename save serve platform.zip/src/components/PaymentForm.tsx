import React, { useState } from 'react';
import {
  PaymentElement,
  useStripe,
  useElements
} from '@stripe/react-stripe-js';
import { motion } from 'motion/react';
import { ShieldCheck, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { db } from '../firebase/firebase';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';

interface PaymentFormProps {
  amount: number;
  donorInfo: { name: string; email: string };
  onSuccess: () => void;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ amount, donorInfo, onSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    try {
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/donate/success`,
          receipt_email: donorInfo.email,
        },
        redirect: 'if_required',
      });

      if (error) {
        setErrorMessage(error.message || 'An unexpected error occurred.');
        toast.error(error.message || 'Payment failed');
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        // Save to Firestore
        await addDoc(collection(db, 'donations'), {
          donorName: donorInfo.name || 'Anonymous',
          donorEmail: donorInfo.email,
          amount: amount,
          currency: 'usd',
          status: 'Succeeded',
          paymentIntentId: paymentIntent.id,
          createdAt: serverTimestamp(),
        });
        
        toast.success('Thank you for your generous donation!');
        onSuccess();
      }
    } catch (err: any) {
      console.error('Payment error:', err);
      setErrorMessage('Failed to process payment. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100">
        <PaymentElement />
      </div>

      {errorMessage && (
        <div className="p-4 bg-red-50 text-red-600 rounded-xl text-sm font-bold">
          {errorMessage}
        </div>
      )}

      <button
        type="submit"
        disabled={!stripe || isProcessing}
        className="w-full py-6 bg-green-600 text-white rounded-2xl font-black text-lg flex items-center justify-center space-x-3 hover:bg-green-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-green-200"
      >
        {isProcessing ? (
          <>
            <Loader2 className="animate-spin" size={20} />
            <span>Processing...</span>
          </>
        ) : (
          <span>Complete Donation of ${amount}</span>
        )}
      </button>

      <div className="flex items-center justify-center space-x-2 text-gray-400">
        <ShieldCheck size={16} />
        <span className="text-[10px] font-black uppercase tracking-widest">Secure SSL Encrypted Payment</span>
      </div>
    </form>
  );
};

export default PaymentForm;
