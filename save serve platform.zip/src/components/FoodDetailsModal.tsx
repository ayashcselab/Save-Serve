import React from 'react';
import { X, Clock, MapPin, Package, User, Calendar, CheckCircle2, ArrowRight } from 'lucide-react';
import { format, differenceInMinutes } from 'date-fns';
import { FoodItem } from '../types';
import { motion } from 'motion/react';

interface FoodDetailsModalProps {
  item: FoodItem;
  isOpen: boolean;
  onClose: () => void;
}

const FoodDetailsModal: React.FC<FoodDetailsModalProps> = ({ item, isOpen, onClose }) => {
  if (!isOpen) return null;

  const getStatusStep = (status: string) => {
    const steps = ['Available', 'Accepted', 'On The Way', 'Collected', 'Distributed'];
    return steps.indexOf(status);
  };

  const currentStep = getStatusStep(item.status);

  const formatTimestamp = (ts: any) => {
    if (!ts) return 'Pending';
    const date = ts.toDate ? ts.toDate() : new Date(ts);
    return format(date, 'MMM d, h:mm a');
  };

  const calculateDuration = (start: any, end: any) => {
    if (!start || !end) return null;
    const startDate = start.toDate ? start.toDate() : new Date(start);
    const endDate = end.toDate ? end.toDate() : new Date(end);
    const mins = differenceInMinutes(endDate, startDate);
    if (mins < 60) return `${mins} mins`;
    const hours = Math.floor(mins / 60);
    const remainingMins = mins % 60;
    return `${hours}h ${remainingMins}m`;
  };

  const totalRescueTime = calculateDuration(item.createdAt, item.distributedAt || item.receivedAt);

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
      >
        <div className="relative h-48 sm:h-64 flex-shrink-0">
          {item.imageUrl ? (
            <img 
              src={item.imageUrl} 
              alt={item.name} 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full bg-green-100 flex items-center justify-center">
              <Package size={48} className="text-green-600" />
            </div>
          )}
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-black/20 hover:bg-black/40 text-white rounded-full backdrop-blur-md transition-colors"
          >
            <X size={20} />
          </button>
          <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent text-white">
            <div className="flex items-center space-x-2 mb-2">
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                item.priority === 'Urgent' ? 'bg-red-500' : 'bg-green-500'
              }`}>
                {item.priority}
              </span>
              <span className="px-2 py-0.5 rounded-full bg-white/20 text-[10px] font-bold uppercase tracking-wider backdrop-blur-md">
                {item.category}
              </span>
            </div>
            <h2 className="text-2xl font-bold">{item.name}</h2>
          </div>
        </div>

        <div className="flex-grow overflow-y-auto p-6 space-y-8">
          {/* Progress Bar */}
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest">Status Progress</h3>
            <div className="relative">
              <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-100 -translate-y-1/2" />
              <div 
                className="absolute top-1/2 left-0 h-1 bg-green-500 -translate-y-1/2 transition-all duration-500" 
                style={{ width: `${(currentStep / 4) * 100}%` }}
              />
              <div className="relative flex justify-between">
                {['Posted', 'Accepted', 'On Way', 'Received', 'Done'].map((step, idx) => (
                  <div key={step} className="flex flex-col items-center space-y-2">
                    <div className={`w-4 h-4 rounded-full border-2 z-10 transition-colors ${
                      idx <= currentStep ? 'bg-green-500 border-green-500' : 'bg-white border-gray-200'
                    }`} />
                    <span className={`text-[10px] font-bold ${
                      idx <= currentStep ? 'text-green-600' : 'text-gray-400'
                    }`}>{step}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest">Donation Details</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 text-gray-600">
                    <Package size={18} className="text-green-500" />
                    <span className="text-sm font-medium">{item.quantity}</span>
                  </div>
                  <div className="flex items-center space-x-3 text-gray-600">
                    <Clock size={18} className="text-green-500" />
                    <span className="text-sm font-medium">Pickup by: {formatTimestamp(item.pickupTime)}</span>
                  </div>
                  <div className="flex items-center space-x-3 text-gray-600">
                    <MapPin size={18} className="text-green-500" />
                    <span className="text-sm font-medium">{item.location}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest">Parties Involved</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 text-gray-600">
                    <div className="w-8 h-8 bg-green-50 rounded-lg flex items-center justify-center text-green-600 font-bold">
                      {item.restaurantName.charAt(0)}
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 font-bold uppercase">Restaurant</p>
                      <p className="text-sm font-bold text-gray-900">{item.restaurantName}</p>
                    </div>
                  </div>
                  {item.ngoName && (
                    <div className="flex items-center space-x-3 text-gray-600">
                      <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 font-bold">
                        {item.ngoName.charAt(0)}
                      </div>
                      <div>
                        <p className="text-[10px] text-gray-400 font-bold uppercase">NGO</p>
                        <p className="text-sm font-bold text-gray-900">{item.ngoName}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-widest">Timeline</h3>
              <div className="space-y-4 relative before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-0.5 before:bg-gray-100">
                <TimelineItem label="Posted" time={item.createdAt} />
                <TimelineItem label="Accepted" time={item.acceptedAt} duration={calculateDuration(item.createdAt, item.acceptedAt)} />
                <TimelineItem label="Pickup Started" time={item.pickupStartedAt} duration={calculateDuration(item.acceptedAt, item.pickupStartedAt)} />
                <TimelineItem label="Received" time={item.receivedAt} duration={calculateDuration(item.pickupStartedAt, item.receivedAt)} />
                <TimelineItem label="Distributed" time={item.distributedAt} duration={calculateDuration(item.receivedAt, item.distributedAt)} />
              </div>
              
              {totalRescueTime && (
                <div className="mt-6 p-4 bg-green-50 rounded-2xl border border-green-100">
                  <p className="text-[10px] text-green-600 font-bold uppercase tracking-wider mb-1">Total Rescue Time</p>
                  <p className="text-xl font-black text-green-700">{totalRescueTime}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const TimelineItem = ({ label, time, duration }: { label: string; time: any; duration?: string | null }) => (
  <div className="relative pl-8">
    <div className={`absolute left-0 top-1.5 w-6 h-6 rounded-full border-4 border-white shadow-sm flex items-center justify-center z-10 ${
      time ? 'bg-green-500' : 'bg-gray-200'
    }`}>
      {time && <CheckCircle2 size={12} className="text-white" />}
    </div>
    <div>
      <p className={`text-xs font-bold ${time ? 'text-gray-900' : 'text-gray-400'}`}>{label}</p>
      {time ? (
        <div className="flex items-center space-x-2">
          <p className="text-[10px] text-gray-500">{format(time.toDate ? time.toDate() : new Date(time), 'MMM d, h:mm a')}</p>
          {duration && (
            <span className="text-[10px] bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded font-medium">
              +{duration}
            </span>
          )}
        </div>
      ) : (
        <p className="text-[10px] text-gray-300 italic">Not yet</p>
      )}
    </div>
  </div>
);

export default FoodDetailsModal;
