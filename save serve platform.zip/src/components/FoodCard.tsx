import React, { useState, useEffect } from 'react';
import { Calendar, MapPin, Package, Clock, CheckCircle2, Loader2, Heart, Info, ArrowRight, Timer } from 'lucide-react';
import { format, differenceInMinutes } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { FoodItem, FoodStatus } from '../types';
import FoodDetailsModal from './FoodDetailsModal';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface FoodCardProps {
  item: FoodItem;
  onAction?: (id: string, nextStatus: FoodStatus) => void;
  isActionLoading?: boolean;
  showRestaurant?: boolean;
  userRole?: 'Restaurant' | 'NGO';
}

const FoodCard: React.FC<FoodCardProps> = ({ 
  item, 
  onAction, 
  isActionLoading,
  showRestaurant = true,
  userRole
}) => {
  const [showDetails, setShowDetails] = useState(false);
  const [elapsedMinutes, setElapsedMinutes] = useState(0);

  useEffect(() => {
    let interval: any;
    if (item.status === 'On The Way' && item.pickupStartedAt) {
      const calculateElapsed = () => {
        const start = item.pickupStartedAt.toDate ? item.pickupStartedAt.toDate() : new Date(item.pickupStartedAt);
        setElapsedMinutes(differenceInMinutes(new Date(), start));
      };
      calculateElapsed();
      interval = setInterval(calculateElapsed, 60000);
    }
    return () => clearInterval(interval);
  }, [item.status, item.pickupStartedAt]);

  const statusColors: Record<FoodStatus, string> = {
    Available: 'bg-green-100 text-green-700 border-green-200',
    Accepted: 'bg-blue-100 text-blue-700 border-blue-200',
    'On The Way': 'bg-yellow-100 text-yellow-700 border-yellow-200',
    Collected: 'bg-purple-100 text-purple-700 border-purple-200',
    Distributed: 'bg-gray-100 text-gray-700 border-gray-200',
    Expired: 'bg-red-100 text-red-700 border-red-200',
  };

  const getNextAction = () => {
    if (userRole !== 'NGO') return null;
    
    switch (item.status) {
      case 'Available':
        return { label: 'Accept Donation', nextStatus: 'Accepted' as FoodStatus, icon: <Heart size={18} /> };
      case 'Accepted':
        return { label: 'Start Pickup', nextStatus: 'On The Way' as FoodStatus, icon: <Timer size={18} /> };
      case 'On The Way':
        return { label: 'Mark as Received', nextStatus: 'Collected' as FoodStatus, icon: <CheckCircle2 size={18} /> };
      case 'Collected':
        return { label: 'Mark as Distributed', nextStatus: 'Distributed' as FoodStatus, icon: <Package size={18} /> };
      default:
        return null;
    }
  };

  const action = getNextAction();
  const pickupDate = item.pickupTime?.toDate ? item.pickupTime.toDate() : new Date(item.pickupTime);
  const isUrgent = item.priority === 'Urgent';

  const getStatusProgress = () => {
    const steps: FoodStatus[] = ['Available', 'Accepted', 'On The Way', 'Collected', 'Distributed'];
    const index = steps.indexOf(item.status);
    return ((index + 1) / steps.length) * 100;
  };

  return (
    <>
      <div className={cn(
        "bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col h-full group relative",
        isUrgent && "ring-2 ring-red-100 border-red-100"
      )}>
        {/* Priority Tag */}
        <div className="absolute top-3 left-3 z-10 flex space-x-2">
          {isUrgent && (
            <span className="bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm animate-pulse">
              Urgent
            </span>
          )}
          <span className="bg-white/90 backdrop-blur-sm text-gray-600 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm border border-gray-100">
            {item.category}
          </span>
        </div>

        {/* Image Section */}
        <div className="aspect-[16/10] w-full overflow-hidden relative">
          {item.imageUrl ? (
            <img 
              src={item.imageUrl} 
              alt={item.name} 
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="w-full h-full bg-green-50 flex items-center justify-center">
              <Package size={48} className="text-green-200" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60" />
          
          {/* Status Overlay */}
          <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
            <span className={cn(
              "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border backdrop-blur-md shadow-sm",
              statusColors[item.status]
            )}>
              {item.status}
            </span>
            {item.status === 'On The Way' && (
              <div className="bg-white/90 backdrop-blur-md px-2 py-1 rounded-lg shadow-sm border border-yellow-100 flex items-center space-x-1.5">
                <div className="w-2 h-2 bg-yellow-500 rounded-full animate-ping" />
                <span className="text-[10px] font-bold text-yellow-700">Pickup: {elapsedMinutes}m</span>
              </div>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-1 w-full bg-gray-100">
          <div 
            className="h-full bg-green-500 transition-all duration-1000 ease-out" 
            style={{ width: `${getStatusProgress()}%` }}
          />
        </div>

        <div className="p-5 flex-grow space-y-4">
          <div className="flex justify-between items-start">
            <h3 className="text-lg font-black text-gray-900 leading-tight group-hover:text-green-600 transition-colors line-clamp-2">
              {item.name}
            </h3>
            <button 
              onClick={() => setShowDetails(true)}
              className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-full transition-all"
              title="View Details"
            >
              <Info size={20} />
            </button>
          </div>
          
          <div className="grid grid-cols-2 gap-3 text-xs font-medium text-gray-500">
            <div className="flex items-center space-x-2 bg-gray-50 p-2 rounded-xl">
              <Package size={14} className="text-green-500 shrink-0" />
              <span className="truncate">{item.quantity}</span>
            </div>
            
            <div className="flex items-center space-x-2 bg-gray-50 p-2 rounded-xl">
              <Clock size={14} className="text-green-500 shrink-0" />
              <span className="truncate">{format(pickupDate, 'h:mm a')}</span>
            </div>

            <div className="flex items-center space-x-2 bg-gray-50 p-2 rounded-xl col-span-2">
              <MapPin size={14} className="text-green-500 shrink-0" />
              <span className="truncate">{item.location}</span>
            </div>
          </div>

          {showRestaurant && (
            <div className="pt-2 flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="w-7 h-7 bg-green-600 rounded-lg flex items-center justify-center text-[10px] font-black text-white shadow-sm">
                  {item.restaurantName.charAt(0)}
                </div>
                <div className="flex flex-col">
                  <span className="text-[9px] font-black text-gray-400 uppercase tracking-wider leading-none">Restaurant</span>
                  <span className="text-xs font-bold text-gray-700 leading-tight">{item.restaurantName}</span>
                </div>
              </div>
              <span className="text-[10px] font-bold text-gray-400">
                {format(item.createdAt?.toDate ? item.createdAt.toDate() : new Date(item.createdAt), 'MMM d')}
              </span>
            </div>
          )}
        </div>

        {/* Action Button */}
        {onAction && action && (
          <div className="p-4 pt-0">
            <button
              onClick={() => onAction(item.id, action.nextStatus)}
              disabled={isActionLoading}
              className={cn(
                "w-full py-3 px-4 rounded-xl font-black text-[11px] uppercase tracking-widest transition-all flex items-center justify-center space-x-2 shadow-sm active:scale-95",
                item.status === 'Available' 
                  ? "bg-green-600 text-white hover:bg-green-700 hover:shadow-green-100" 
                  : "bg-blue-600 text-white hover:bg-blue-700 hover:shadow-blue-100",
                isActionLoading && "opacity-70 cursor-not-allowed"
              )}
            >
              {isActionLoading ? (
                <Loader2 size={18} className="animate-spin" />
              ) : (
                <>
                  {action.icon}
                  <span>{action.label}</span>
                </>
              )}
            </button>
          </div>
        )}

        {/* View Details Quick Link */}
        {!onAction && (
          <div className="p-4 pt-0">
            <button
              onClick={() => setShowDetails(true)}
              className="w-full py-3 px-4 rounded-xl font-black text-[11px] uppercase tracking-widest bg-gray-100 text-gray-600 hover:bg-gray-200 transition-all flex items-center justify-center space-x-2"
            >
              <ArrowRight size={16} />
              <span>View Full Details</span>
            </button>
          </div>
        )}
      </div>

      <FoodDetailsModal 
        item={item} 
        isOpen={showDetails} 
        onClose={() => setShowDetails(false)} 
      />
    </>
  );
};

export default FoodCard;
