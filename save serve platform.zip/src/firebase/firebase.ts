import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyDFe_FuzfTHqdFHrY3fONa0vah46FDht0k",
  authDomain: "save-and-serve-cc823.firebaseapp.com",
  projectId: "save-and-serve-cc823",
  storageBucket: "save-and-serve-cc823.firebasestorage.app",
  messagingSenderId: "455260401991",
  appId: "1:455260401991:web:bb593586d108cd1fae9c62",
  measurementId: "G-09WYXMRJ1R"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
