import { 
  collection, 
  addDoc, 
  updateDoc, 
  doc, 
  serverTimestamp, 
  query, 
  where, 
  orderBy, 
  onSnapshot,
  getDocs,
  increment,
  setDoc
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../firebase/firebase';
import { FoodItem, FoodStatus } from '../types';

export const foodService = {
  async uploadFood(food: Omit<FoodItem, 'id' | 'createdAt' | 'updatedAt' | 'statusHistory' | 'createdBy'>, imageFile?: File) {
    let imageUrl = food.imageUrl || '';
    if (imageFile) {
      const storageRef = ref(storage, `food-images/${Date.now()}_${imageFile.name}`);
      await uploadBytes(storageRef, imageFile);
      imageUrl = await getDownloadURL(storageRef);
    }

    const docRef = await addDoc(collection(db, 'foodItems'), {
      ...food,
      imageUrl,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      statusHistory: [{
        status: food.status,
        timestamp: new Date(),
        updatedBy: food.restaurantId,
        notes: 'Food donation posted'
      }],
      createdBy: food.restaurantId,
      isDeleted: false
    });

    // Notify NGOs
    await this.createNotificationForNGOs(`New food donation available: ${food.name} from ${food.restaurantName}`);
    
    return docRef.id;
  },

  async createNotificationForNGOs(message: string) {
    const ngosQuery = query(collection(db, 'users'), where('role', '==', 'NGO'));
    const ngosSnapshot = await getDocs(ngosQuery);
    
    const promises = ngosSnapshot.docs.map(ngoDoc => 
      addDoc(collection(db, 'notifications'), {
        userId: ngoDoc.id,
        message,
        type: 'new_food',
        read: false,
        createdAt: serverTimestamp(),
      })
    );
    await Promise.all(promises);
  },

  async acceptPickup(foodId: string, ngoId: string, ngoName: string, restaurantId: string) {
    const itemRef = doc(db, 'foodItems', foodId);
    
    await updateDoc(itemRef, {
      status: 'Accepted',
      ngoId,
      ngoName,
      acceptedAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    // Notify Restaurant
    await addDoc(collection(db, 'notifications'), {
      userId: restaurantId,
      message: `NGO ${ngoName} has accepted your food donation.`,
      type: 'pickup_accepted',
      read: false,
      createdAt: serverTimestamp(),
    });
  },

  async markCollected(foodId: string, ngoId: string) {
    await updateDoc(doc(db, 'foodItems', foodId), {
      status: 'Collected',
      receivedAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
  },

  async markDistributed(foodId: string, restaurantId: string, ngoId: string) {
    await updateDoc(doc(db, 'foodItems', foodId), {
      status: 'Distributed',
      distributedAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    // Update Analytics
    await this.updateAnalytics(restaurantId, ngoId);
  },

  async updateAnalytics(restaurantId: string, ngoId: string) {
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
    
    const analyticsRef = doc(db, 'analytics', `${dateStr}_${restaurantId}_${ngoId}`);
    
    await setDoc(analyticsRef, {
      type: 'daily',
      restaurantId,
      ngoId,
      totalDonated: increment(1),
      totalCollected: increment(1),
      timestamp: serverTimestamp()
    }, { merge: true });
  }
};
